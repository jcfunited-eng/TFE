import streamlit as st
import pandas as pd

# Path to your portfolio file
PORTFOLIO_PATH = "portfolio.csv"

# Allowed asset type labels
ASSET_TYPES = ["equity", "crypto", "index", "other"]


def normalize_asset_type(value: object) -> str:
    """Map various labels into a small set of asset types."""
    if not isinstance(value, str):
        return "other"
    v = value.strip().lower()
    if v in ("equity", "stock", "etf", "shares"):
        return "equity"
    if v in ("crypto", "cryptocurrency"):
        return "crypto"
    if v in ("index",):
        return "index"
    return "other"


def load_portfolio() -> pd.DataFrame:
    """
    Load the portfolio file and normalize columns.
    Handles both comma- and tab-delimited files.
    """
    # sep=None + engine='python' lets pandas auto-detect comma vs tab
    df = pd.read_csv(PORTFOLIO_PATH, sep=None, engine="python")

    # Normalize column names
    df.columns = [str(c).strip().lower() for c in df.columns]

    # Ensure required columns exist
    required = {"ticker", "quantity", "cost_basis"}
    if not required.issubset(df.columns):
        raise ValueError(
            f"portfolio.csv must have columns: {', '.join(sorted(required))}. "
            f"Found: {df.columns.tolist()}"
        )

    if "asset_type" not in df.columns:
        df["asset_type"] = "equity"

    # Normalize asset_type values
    df["asset_type"] = df["asset_type"].apply(normalize_asset_type)

    # Keep a consistent column order
    df = df[["ticker", "quantity", "cost_basis", "asset_type"]]
    return df


def save_portfolio(df: pd.DataFrame) -> None:
    """Save portfolio to disk as a proper CSV (comma-separated)."""
    df.to_csv(PORTFOLIO_PATH, index=False)


def main():
    st.set_page_config(page_title="Portfolio Manager", layout="wide")
    st.title("🧺 Portfolio Manager (Standalone)")

    try:
        df = load_portfolio()
    except Exception as e:
        st.error(f"Could not load portfolio.csv: {e}")
        return

    tickers = list(df["ticker"])

    tab_add, tab_remove, tab_update, tab_view = st.tabs(
        ["➕ Add Asset", "🗑 Remove Asset", "✏️ Update Asset", "📋 View Raw Data"]
    )

    # ----------------------------------------------------------------------
    # ADD ASSET
    # ----------------------------------------------------------------------
    with tab_add:
        st.subheader("Add Asset")

        new_ticker = st.text_input("Ticker (e.g., AAPL, BTC-USD)").upper().strip()
        new_qty = st.number_input("Quantity", min_value=0.0, format="%.4f")
        new_cost = st.number_input("Cost basis ($ per unit)", min_value=0.0, format="%.4f")
        new_type = st.selectbox("Asset type", ASSET_TYPES, index=0, key="add_type")

        if st.button("Add to portfolio", key="add_btn"):
            if not new_ticker:
                st.error("Ticker cannot be empty.")
            else:
                new_row = pd.DataFrame(
                    [{
                        "ticker": new_ticker,
                        "quantity": new_qty,
                        "cost_basis": new_cost,
                        "asset_type": new_type,
                    }]
                )
                new_df = pd.concat([df, new_row], ignore_index=True)
                save_portfolio(new_df)
                st.success(f"Added {new_ticker} to portfolio.")
                st.rerun()

    # ----------------------------------------------------------------------
    # REMOVE ASSET
    # ----------------------------------------------------------------------
    with tab_remove:
        st.subheader("Remove Asset")

        if not tickers:
            st.info("Portfolio is empty.")
        else:
            # Use index selection to avoid mask confusion
            idx = st.selectbox(
                "Select asset to remove",
                df.index,
                format_func=lambda i: f"{df.loc[i, 'ticker']} (qty={df.loc[i, 'quantity']})",
                key="remove_select",
            )

            if st.button("Remove asset", key="remove_btn"):
                new_df = df.drop(index=idx)
                save_portfolio(new_df)
                st.success(f"Removed {df.loc[idx, 'ticker']}.")
                st.rerun()

    # ----------------------------------------------------------------------
    # UPDATE ASSET
    # ----------------------------------------------------------------------
    with tab_update:
        st.subheader("Update Asset")

        if not tickers:
            st.info("Portfolio is empty.")
        else:
            idx = st.selectbox(
                "Select asset to update",
                df.index,
                format_func=lambda i: f"{df.loc[i, 'ticker']} (qty={df.loc[i, 'quantity']})",
                key="update_select",
            )

            row = df.loc[idx]

            new_qty = st.number_input(
                "Quantity",
                min_value=0.0,
                value=float(row["quantity"]),
                format="%.4f",
                key="update_qty",
            )
            new_cost = st.number_input(
                "Cost basis ($ per unit)",
                min_value=0.0,
                value=float(row["cost_basis"]),
                format="%.4f",
                key="update_cost",
            )
            current_type = normalize_asset_type(row["asset_type"])
            new_type = st.selectbox(
                "Asset type",
                ASSET_TYPES,
                index=ASSET_TYPES.index(current_type),
                key="update_type",
            )

            if st.button("Save changes", key="update_btn"):
                new_df = df.copy()
                new_df.at[idx, "quantity"] = new_qty
                new_df.at[idx, "cost_basis"] = new_cost
                new_df.at[idx, "asset_type"] = new_type
                save_portfolio(new_df)
                st.success(f"Updated {row['ticker']}.")
                st.rerun()

    # ----------------------------------------------------------------------
    # VIEW RAW DATA
    # ----------------------------------------------------------------------
    with tab_update:
        pass  # placeholder, real logic above

    with tab_view:
        st.subheader("Current portfolio data (raw)")
        st.dataframe(df, use_container_width=True)


if __name__ == "__main__":
    main()
