"""
Test for Hardening Trigger Condition HTC-1 (DSF Collapse).

We provide a simulated stability_scores dict with a DSF stability value
below the threshold (0.3), expecting:

    flags.dsf_collapse == True
    raw_metrics["dsf_stability"] == provided value
    notes includes factual collapse message
"""

import os
import sys

# Ensure project root is visible
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = current_dir
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from uf_core.hardening import evaluate_htc, HardeningEvaluationResult


def main():
    # Simulate DSF stability (same as your validation dataset: 0.142857)
    stability_scores = {"dsf": 0.142857}

    result = evaluate_htc(stability_scores=stability_scores)

    print("HTC-1 DSF Collapse Test Result:")
    print(result)

    print("\nFlags:", result.flags)
    print("Raw metrics:", result.raw_metrics)
    print("Notes:", result.notes)

    # Explicit checks
    print("\nExplicit Checks:")
    print("DSF Collapse Flag:", result.flags.dsf_collapse)
    print("Stored DSF Stability:", result.raw_metrics.get("dsf_stability"))
    print("Has collapse note:",
          any("below threshold" in note for note in result.notes))


if __name__ == "__main__":
    main()
