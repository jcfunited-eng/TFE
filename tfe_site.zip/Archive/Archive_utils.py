# utils.py
# Shared utilities + constants used across all pages

import pandas as pd
import data_loader
import portfolio

from engine import get_history_range, get_portfolio_and_prices, get_history_with_indicators

# ========================================================
# COLOR + THEME CONSTANTS
# ========================================================
UP_COLOR = "#00B050"
DOWN_COLOR = "#C00000"
PLOTLY_TEMPLATE = "plotly_dark"

# ========================================================
# PORTFOLIO LOADING (wrapper)
# ========================================================
def load_portfolio():
    """
    Proxy to engine.get_portfolio_and_prices() so pages call utils.load_portfolio().
    """
    return get_portfolio_and_prices()

# ========================================================
# HISTORY RANGE (wrapper)
# ========================================================
def history_range(code: str):
    return get_history_range(code)

# ========================================================
# PRICE HISTORY + INDICATORS (wrapper)
# ========================================================
def load_history_with_indicators(ticker: str, period="6mo", interval="1d"):
    return get_history_with_indicators(ticker, period, interval)
