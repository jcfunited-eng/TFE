from dataclasses import dataclass
from typing import Dict, List, Optional

from portfolio import PortfolioSnapshot


@dataclass
class Recommendation:
    """
    Simple container for recommendations.
    """
    title: str
    detail: str
    severity: str  # "info", "low", "medium", "high"


@dataclass
class RecommendationSummary:
    """
    Bundle of recommendations and high-level summary text.
    """
    summary: str
    opportunities: List[Recommendation]
    risks: List[Recommendation]
    notes: List[Recommendation]


def _detect_concentration(
    weights: Dict[str, float],
    threshold: float = 0.30,
) -> Optional[Recommendation]:
    large = {t: w for t, w in weights.items() if w >= threshold}
    if not large:
        return None

    tickers = ", ".join(
        f"{t} ({w:.0%})" for t, w in sorted(large.items(), key=lambda kv: kv[1], reverse=True)
    )
    return Recommendation(
        title="Concentration risk",
        detail=f"One or more positions are larger than {threshold:.0%} of your portfolio: {tickers}. "
               f"Consider whether you are comfortable with this level of concentration.",
        severity="medium",
    )


def _diversification_note(
    div_score: float,
) -> Recommendation:
    if div_score < 0.2:
        level = "very low"
        severity = "medium"
    elif div_score < 0.4:
        level = "low"
        severity = "low"
    elif div_score < 0.7:
        level = "moderate"
        severity = "info"
    else:
        level = "high"
        severity = "info"

    return Recommendation(
        title="Diversification level",
        detail=f"Your diversification score is {div_score:.2f}, which is {level}. "
               "This is a simplified metric and should be interpreted together with your goals and risk tolerance.",
        severity=severity,
    )


def build_recommendations(
    snapshot: PortfolioSnapshot,
    risk_metrics: Dict[str, float],
    risk_tolerance: str = "moderate",
) -> RecommendationSummary:
    """
    Create a set of high-level, educational recommendations.

    risk_metrics can include keys like:
        - 'volatility'
        - 'max_drawdown'
        - 'sharpe'
        - 'beta'

    NOTE:
        This module is educational and illustrative only.
        It is NOT personalized financial advice.
    """
    opportunities: List[Recommendation] = []
    risks: List[Recommendation] = []
    notes: List[Recommendation] = []

    # Diversification
    div_note = _diversification_note(snapshot.diversification_score)
    notes.append(div_note)

    # Concentration
    conc = _detect_concentration(snapshot.weights)
    if conc is not None:
        risks.append(conc)

    # Risk-level summary using volatility & drawdown if provided
    vol = risk_metrics.get("volatility")
    max_dd = risk_metrics.get("max_drawdown")

    if vol is not None and max_dd is not None:
        if vol > 0.25 or max_dd < -0.30:
            risks.append(
                Recommendation(
                    title="High risk profile",
                    detail="Your portfolio shows relatively high volatility and/or deep historical drawdowns. "
                           "Ensure this matches your time horizon and comfort with risk.",
                    severity="high",
                )
            )
        elif vol < 0.10 and max_dd > -0.10:
            opportunities.append(
                Recommendation(
                    title="Capacity for more risk (if desired)",
                    detail="Your portfolio appears relatively conservative. "
                           "If your time horizon is long and you are comfortable with more risk, "
                           "you may have room to increase growth exposure.",
                    severity="info",
                )
            )

    # Simple summary text for top-level display
    if risks:
        summary = (
            "Your portfolio is generally okay, but there are some areas that may warrant attention. "
            "Review the concentration and risk notes below and decide what fits your goals."
        )
    else:
        summary = (
            "Your portfolio looks reasonably balanced based on these simple checks. "
            "Continue monitoring periodically and keep aligning decisions with your goals and time horizon."
        )

    return RecommendationSummary(
        summary=summary,
        opportunities=opportunities,
        risks=risks,
        notes=notes,
    )
