import pandas as pd
import numpy as np

from uf_core.layer0 import compute_sev_series
from uf_core.layer1 import segment_gates
from uf_core.layer2 import interpret_gates
from uf_core.config import KERNEL_THRESHOLDS


def main():
    prices = [100, 101, 102, 110, 111, 112, 113, 90, 91, 92, 93, 94]
    df = pd.DataFrame({"Close": prices})

    sev_list = compute_sev_series(df)
    gates = segment_gates(sev_list)
    interpretations = interpret_gates(sev_list, gates)

    print("Total gates:", len(gates))
    print("Total interpretations:", len(interpretations))
    print("U_max (threshold) =", KERNEL_THRESHOLDS.U_max)

    for idx, interp in enumerate(interpretations, start=1):
        gate = interp.gate
        CV_k = np.array(interp.CV_k)
        w_k = interp.w_k
        S_k = interp.S_k
        U_k = interp.U_k
        IAS_k = interp.IAS_k

        print(f"\nGate {idx}:")
        print(f" Index range = [{gate.start_idx}, {gate.end_idx}]")
        print(f" w_k         = {w_k:.6f}")
        print(f" ||CV_k||    = {np.linalg.norm(CV_k):.6f}")
        print(f" S_k         = {S_k:.6f}")
        print(f" U_k         = {U_k:.6f}")
        print(f" IAS_k       = {IAS_k} (1 iff U_k > U_max)")


if __name__ == "__main__":
    main()
