import pandas as pd
import numpy as np

from uf_core.layer0 import compute_sev_series
from uf_core.layer1 import segment_gates
from uf_core.layer2 import interpret_gates
from uf_core.layer3 import compute_resonance


def main():
    prices = [100, 101, 102, 110, 111, 112, 113, 90, 91, 92, 93, 94]
    df = pd.DataFrame({"Close": prices})

    sev_list = compute_sev_series(df)
    gates = segment_gates(sev_list)
    interpretations = interpret_gates(sev_list, gates)
    resonance_results = compute_resonance(interpretations)

    print("Total gates:", len(gates))
    print("Total resonance results:", len(resonance_results))
    print("Hysteresis threshold h_max = 0.20")

    R_values = [res.R_k for res in resonance_results]

    for idx, res in enumerate(resonance_results, start=1):
        interp = res.interpretation
        gate = interp.gate
        H_k = res.Hyst_k
        R_k = res.R_k

        prev_R = R_values[idx-2] if idx > 1 else None
        if prev_R is None:
            delta = None
        else:
            delta = abs(R_k - prev_R)

        print(f"\nGate {idx}:")
        print(f" Index range = [{gate.start_idx}, {gate.end_idx}]")
        print(f" R_k         = {R_k:.6f}")
        print(f" Hyst_k      = {H_k}")
        print(f" ΔR (vs prev) = {delta if delta is not None else 'N/A'}")


if __name__ == "__main__":
    main()
