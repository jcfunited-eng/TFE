import pandas as pd

import data_loader
import portfolio
import risk


# Load portfolio from CSV
positions = pd.read_csv("portfolio.csv")

# Extract tickers from the file
tickers = list(positions["ticker"])

# Load latest prices
latest = data_loader.latest_prices(tickers)
print("Latest prices:")
print(latest)

# Build portfolio snapshot
snapshot = portfolio.compute_portfolio_snapshot(positions, latest)

print("\nPortfolio snapshot:")
print(f"Total value          : {snapshot.total_value:.2f}")
print(f"Cost basis value     : {snapshot.cost_basis_value:.2f}")
print(f"Unrealized P/L       : {snapshot.unrealized_pl:.2f}")
print(f"Unrealized P/L %     : {snapshot.unrealized_pl_pct:.2%}")
print(f"Diversification score: {snapshot.diversification_score:.2f}")
print(f"Weights              : {snapshot.weights}")

# Risk metrics for each ticker
print("\nRisk metrics per ticker:")
for ticker in tickers:
    df = data_loader.load_price_history(ticker)
    returns = risk.daily_returns(df["close"])
    vol = risk.annualized_volatility(returns)
    sharpe = risk.sharpe_ratio(returns, risk_free_rate=0.02)
    equity = (1 + returns).cumprod() * 10_000
    max_dd, dd_days = risk.max_drawdown(equity)

    print(f"\n{ticker}:")
    print(f"  volatility: {vol:.4f}")
    print(f"  sharpe    : {sharpe:.4f}")
    print(f"  max_dd    : {max_dd:.2%}")
    print(f"  dd_days   : {dd_days}")
