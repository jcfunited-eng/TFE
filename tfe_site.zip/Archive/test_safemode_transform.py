"""
Test for apply_safemode_transform() — SafeMode DSF behavior.

Scenarios:
1) SafeMode inactive → DSF unchanged.
2) SafeMode active   → Total action freeze:
       D, M, R_rev, P, B → 0
       U*_k unchanged.
"""

import os
import sys

# Ensure project root importable
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = current_dir
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from uf_core.safemode import SafeModeState, apply_safemode_transform
from uf_core.layer4 import DSF


def make_sample_dsf():
    return [
        DSF(
            gate=None,
            D_k=1.0,
            M_k=2.0,
            R_rev_k=3.0,
            U_star_k=0.80,
            P_k=4.0,
            B_k=5.0,
        ),
        DSF(
            gate=None,
            D_k=-1.0,
            M_k=-2.0,
            R_rev_k=-3.0,
            U_star_k=0.60,
            P_k=-4.0,
            B_k=-5.0,
        ),
    ]


def main():
    print("=== SafeMode Transform Test ===\n")

    dsf_list = make_sample_dsf()

    # Case 1: SafeMode inactive → unchanged
    state_inactive = SafeModeState(safe_mode=False)
    out_inactive = apply_safemode_transform(dsf_list, state_inactive)

    print("Case 1 — SafeMode inactive (DSF should be unchanged):")
    for dsf in out_inactive:
        print(dsf)

    print("\nExplicit Checks (inactive):")
    for i, (orig, dsf) in enumerate(zip(dsf_list, out_inactive)):
        print(
            f"Entry {i}: "
            f"D: {orig.D_k} -> {dsf.D_k}, "
            f"M: {orig.M_k} -> {dsf.M_k}, "
            f"R_rev: {orig.R_rev_k} -> {dsf.R_rev_k}, "
            f"P: {orig.P_k} -> {dsf.P_k}, "
            f"B: {orig.B_k} -> {dsf.B_k}, "
            f"U*: {orig.U_star_k} -> {dsf.U_star_k}"
        )

    # Case 2: SafeMode active → total action freeze
    state_active = SafeModeState(safe_mode=True)
    out_active = apply_safemode_transform(dsf_list, state_active)

    print("\nCase 2 — SafeMode active (DSF should be fully suppressed):")
    for dsf in out_active:
        print(dsf)

    print("\nExplicit Checks (active):")
    for i, (orig, dsf) in enumerate(zip(dsf_list, out_active)):
        print(
            f"Entry {i}: "
            f"D: {orig.D_k} -> {dsf.D_k}, "
            f"M: {orig.M_k} -> {dsf.M_k}, "
            f"R_rev: {orig.R_rev_k} -> {dsf.R_rev_k}, "
            f"P: {orig.P_k} -> {dsf.P_k}, "
            f"B: {orig.B_k} -> {dsf.B_k}, "
            f"U*: {orig.U_star_k} -> {dsf.U_star_k}"
        )


if __name__ == "__main__":
    main()
