import pandas as pd

from uf_core.layer0 import compute_sev_series
from uf_core.layer1 import segment_gates, compute_gate_tvr
from uf_core.config import KERNEL_THRESHOLDS


def main():
    # Synthetic price series producing distinct gates and non-trivial TVR_k values
    prices = [100, 101, 102, 110, 111, 112, 113, 90, 91, 92, 93, 94]

    df = pd.DataFrame({"Close": prices})

    # L0: Compute SEVs
    sev_list = compute_sev_series(df)

    # L1: Gate segmentation
    gates = segment_gates(sev_list)

    # L1: TVR extraction
    tvr_list = compute_gate_tvr(sev_list, gates)

    print("Number of gates:", len(gates))
    print("Number of TVR vectors:", len(tvr_list))

    for idx, (gate, tvr) in enumerate(zip(gates, tvr_list), start=1):
        (dT, dF_mean, sigma_mean, kappa_mean) = tvr
        print(f"\nGate {idx}:")
        print(f" Index range = [{gate.start_idx}, {gate.end_idx}]")
        print(f" ΔT_k        = {dT}")
        print(f" mean|ΔF|    = {dF_mean:.4f}")
        print(f" mean σ      = {sigma_mean:.4f}")
        print(f" mean κ      = {kappa_mean:.4f}")


if __name__ == "__main__":
    main()
