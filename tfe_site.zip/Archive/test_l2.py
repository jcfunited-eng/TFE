import pandas as pd
import numpy as np

from uf_core.layer0 import compute_sev_series
from uf_core.layer1 import segment_gates
from uf_core.layer2 import interpret_gates


def main():
    # Same synthetic series used before
    prices = [100, 101, 102, 110, 111, 112, 113, 90, 91, 92, 93, 94]

    df = pd.DataFrame({"Close": prices})

    # L0: SEV series
    sev_list = compute_sev_series(df)

    # L1: gates
    gates = segment_gates(sev_list)

    # L2: interpretive layer (Part 1)
    interpretations = interpret_gates(sev_list, gates)

    print("Number of gates:", len(gates))
    print("Number of interpretations:", len(interpretations))

    for idx, interp in enumerate(interpretations, start=1):
        gate = interp.gate
        w_k = interp.w_k
        CV_k = np.array(interp.CV_k, dtype=float)
        S_k = interp.S_k

        print(f"\nGate {idx}:")
        print(f" Index range      = [{gate.start_idx}, {gate.end_idx}]")
        print(f" w_k (weight)     = {w_k:.6f}")
        print(f" ||CV_k||         = {np.linalg.norm(CV_k):.6f}")
        print(f" S_k (score)      = {S_k:.6f}")


if __name__ == "__main__":
    main()
