"""
Test for Hardening Trigger Condition HTC-7 (Gate Drift Excess).

We supply:
    gate_drift_rate = 0.6  (> threshold 0.25)

Expected:
    flags.gate_drift_excess == True
    raw_metrics['gate_drift_rate'] == 0.6
    notes contains 'Gate drift rate above threshold (0.25)'

All other hardening flags should remain False.
"""

import os
import sys

# Ensure project root on path
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = current_dir
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from uf_core.hardening import (
    evaluate_htc,
    KernelStatusFlags,
    HardeningEvaluationResult,
)


def main():
    stability_scores = {
        "gate_drift_rate": 0.6
    }

    result = evaluate_htc(stability_scores=stability_scores)

    print("HTC-7 Gate Drift Excess Test Result:")
    print(result)

    print("\nFlags:", result.flags)
    print("Raw metrics:", result.raw_metrics)
    print("Notes:", result.notes)

    print("\nExplicit Checks:")
    print("Gate Drift Excess Flag (should be True):", result.flags.gate_drift_excess)
    print("Stored Gate Drift Rate:", result.raw_metrics.get("gate_drift_rate"))
    print(
        "Has gate drift excess note:",
        any("Gate drift rate above threshold" in note for note in result.notes),
    )

    # Ensure no other flags fired
    print("\nDSF Collapse Flag (should be False):", result.flags.dsf_collapse)
    print("Directional Collapse Flag (should be False):", result.flags.directional_collapse)
    print("Hysteresis Overload Flag (should be False):", result.flags.hysteresis_overload)
    print("Breathing Instability Flag (should be False):", result.flags.breathing_instability)
    print("Composite S_low Flag (should be False):", result.flags.composite_S_low)
    print("Composite R_low Flag (should be False):", result.flags.composite_R_low)
    print("Uncertainty Excess Flag (should be False):", result.flags.uncertainty_excess)


if __name__ == "__main__":
    main()
