"""
uf_structural_engine.py
-----------------------------------------
UF-Core Structural Engine Adapter for TFE (v1.0)

THIS MODULE NOW USES THE REAL UF-CORE:

    L0: uf_core.layer0.compute_sev_series
    L1: uf_core.layer1.segment_gates
    L2: uf_core.layer2.interpret_gates
    L3: uf_core.layer3.compute_resonance
    L4: uf_core.layer4.compute_directional_signal, compute_dsf
    Hardening: uf_core.hardening.evaluate_htc
    SafeMode: uf_core.safemode, uf_core.hardening_controller (optional)

Public API exposed to TFE:

    compute_uf_structural_state(close: pd.Series) -> UFStructuralState

UFStructuralState is a high-level view suitable for Advisor/Recommendations,
but all structural information is derived from TRUE UF-Core pipelines.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Any, List

import numpy as np
import pandas as pd

from uf_core.config import KERNEL_THRESHOLDS
from uf_core.layer0 import compute_sev_series, SEV
from uf_core.layer1 import segment_gates, Gate
from uf_core.layer2 import interpret_gates, GateInterpretation
from uf_core.layer3 import compute_resonance, ResonanceResult
from uf_core.layer4 import (
    compute_directional_signal,
    compute_dsf,
    DecisionState,
    DSF,
)
from uf_core.hardening import evaluate_htc
from uf_core.hardening_controller import hardening_control_step
from uf_core.safemode import init_safemode_state


# ============================================================
# UF Structural State for TFE
# ============================================================

@dataclass
class UFStructuralState:
    """
    High-level UF structural summary for a single asset, as seen by TFE.

    NOTE:
      - All fields are derived from uf_core.*.
      - Level5.decision_vector is taken directly from the final DSF_k.
    """

    level1: Dict[str, float]
    level2: Dict[str, float]
    level3: Dict[str, Any]
    level4: Dict[str, float]
    level5: Dict[str, Any]


# ============================================================
# Helper functions (pure math, UF-aligned)
# ============================================================

def _safe_pct_change(series: pd.Series) -> pd.Series:
    return series.pct_change().replace([np.inf, -np.inf], np.nan).dropna()


def _max_drawdown(returns: pd.Series) -> float:
    if returns.empty:
        return 0.0
    equity = (1 + returns).cumprod()
    peak = equity.cummax()
    dd = (equity - peak) / peak
    return float(dd.min())  # negative


def _compute_basic_features(close: pd.Series) -> Dict[str, float]:
    """
    L1-like basic behavior from raw prices (UF-compatible, but not TA-only).
    """
    close = close.astype(float)
    returns = _safe_pct_change(close)
    vol = float(returns.std() * np.sqrt(252)) if len(returns) > 0 else 0.0
    avg_ret = float(returns.mean() * 252) if len(returns) > 0 else 0.0
    price_range = float((close.max() - close.min()) / close.min()) if close.min() > 0 else 0.0
    return {
        "n": float(len(close)),
        "vol": vol,
        "avg_return": avg_ret,
        "price_range": price_range,
    }


def _compute_trend_curvature(close: pd.Series) -> Dict[str, float]:
    close = close.astype(float)
    n = len(close)
    if n < 3:
        return {"trend_strength": 0.0, "curvature": 0.0, "slope": 0.0}

    x = np.arange(n)
    y = close.values
    slope, intercept = np.polyfit(x, y, 1)
    trend_strength = float((slope / close.iloc[0]) * n) if close.iloc[0] != 0 else 0.0

    # Second-order fit curvature
    quad_coeffs = np.polyfit(x, y, 2)
    y_quad = np.polyval(quad_coeffs, x)
    curvature = float(np.mean(np.abs(y_quad - y)) / close.iloc[0]) if close.iloc[0] != 0 else 0.0

    return {
        "trend_strength": trend_strength,
        "curvature": curvature,
        "slope": float(slope),
    }


def _aggregate_gate_regime(interpretations: List[GateInterpretation]) -> str:
    """
    Aggregate L2 regimes across gates; we bias towards the last gate
    (most recent structural state), but fall back to majority if needed.
    """
    if not interpretations:
        return "UNKNOWN"
    last_reg = interpretations[-1].regime
    return last_reg


def _compute_stability_from_l4(results: List[ResonanceResult], decision_states: List[DecisionState]) -> Dict[str, float]:
    """
    Derive stability-like metrics from L3/L4 outputs to feed into the
    hardening framework and TFE-level stability view.

    These are grounded in UF-Core data, but threshold calibration still belongs
    to the UF validation suite.
    """
    if not results or not decision_states:
        return {
            "dsf": 1.0,
            "directional": 1.0,
            "hysteresis_rate": 0.0,
            "breathing_rate": 0.0,
            "uncertainty_rate": 0.0,
            "gate_drift_rate": 0.0,
        }

    # Hysteresis and gating rates from L3
    hyst_flags = np.array([res.Hyst_k for res in results], dtype=float)
    hyst_rate = float(np.mean(hyst_flags)) if len(hyst_flags) > 0 else 0.0

    # Use R_k as a proxy for "resonance quality"
    R_vals = np.array([res.R_k for res in results], dtype=float)
    R_mean = float(np.mean(R_vals)) if len(R_vals) > 0 else 0.0

    # L4 directional / DSF stability proxies
    D_vals = np.array([ds.D_k for ds in decision_states], dtype=float)
    B_vals = np.array([ds.B_k for ds in decision_states], dtype=float)
    U_star_vals = np.array([ds.U_star_k for ds in decision_states], dtype=float)

    # Directional stability: fewer reversals, fewer sign flips
    rev_flags = np.array([ds.R_rev_k for ds in decision_states], dtype=float)
    directional_stability = float(1.0 - np.mean(rev_flags)) if len(rev_flags) > 0 else 1.0

    # DSF stability: fewer large absolute D_k and B_k
    dsf_instability = float(np.mean((np.abs(D_vals) > 0).astype(float))) if len(D_vals) > 0 else 0.0
    breathing_instability = float(np.mean((np.abs(B_vals) != 0).astype(float))) if len(B_vals) > 0 else 0.0
    dsf_stability = float(1.0 - dsf_instability)

    # Uncertainty rate (1 - mean U_star)
    if len(U_star_vals) > 0:
        uncertainty_rate = float(1.0 - np.mean(U_star_vals))
    else:
        uncertainty_rate = 0.0

    return {
        "dsf": dsf_stability,
        "directional": directional_stability,
        "hysteresis_rate": hyst_rate,
        "breathing_rate": breathing_instability,
        "uncertainty_rate": uncertainty_rate,
        "gate_drift_rate": 0.0,  # gate drift over time would require cross-run tracking
        "R_mean": R_mean,
    }


# ============================================================
# Core public API
# ============================================================

def compute_uf_structural_state(close: pd.Series) -> UFStructuralState:
    """
    MAIN ENTRYPOINT: true UF-Core pipeline for a single asset.

    Steps:
      1) Build a DataFrame with a 'Close' column.
      2) Run L0 → L1 → L2 → L3 → L4 (uf_core.*).
      3) Aggregate gate-level interpretations and resonance results.
      4) Compute stability metrics and composite S_UF / R_UF.
      5) Run hardening + safemode (Option 3).
      6) Build UFStructuralState for TFE layers to consume.

    NOTE:
      - This function does NOT make buy/sell decisions.
      - It exposes structure for uf_decision_surface and TFE pages.
    """

    close = close.dropna().astype(float)
    if len(close) < 10:
        # Degenerate state
        level1 = {"n": float(len(close)), "vol": 0.0, "avg_return": 0.0, "price_range": 0.0}
        level2 = {"trend_strength": 0.0, "curvature": 0.0, "slope": 0.0}
        level3 = {"regime": "INSUFFICIENT_DATA"}
        level4 = {"max_drawdown": 0.0, "stability_score": 0.0}
        level5 = {"decision_vector": [], "dsf_list": [], "hardening": {}, "safemode": {}}
        return UFStructuralState(level1, level2, level3, level4, level5)

    # --------------------------------------------------------
    # 1) Build DF
    # --------------------------------------------------------
    df = pd.DataFrame({"Close": close})
    df.index = close.index  # preserve time index

    # --------------------------------------------------------
    # 2) L0 → L1 → L2 → L3 → L4
    # --------------------------------------------------------

    # L0: SEV series
    sev_list: List[SEV] = compute_sev_series(df, price_col="Close")

    # L1: Gate segmentation
    gates: List[Gate] = segment_gates(sev_list)

    # L2: Interpret gates
    interpretations: List[GateInterpretation] = interpret_gates(sev_list, gates)

    # L3: Resonance
    resonance_results: List[ResonanceResult] = compute_resonance(interpretations)

    # L4: Directional signal & DSF
    decision_states: List[DecisionState] = compute_directional_signal(resonance_results)
    dsf_list: List[DSF] = compute_dsf(decision_states)

    # --------------------------------------------------------
    # 3) Aggregate regimes & stability metrics (UF-Core grounded)
    # --------------------------------------------------------

    # Regime: take last gate's regime (most recent structural state)
    regime = _aggregate_gate_regime(interpretations)

    # Basic structural features from raw prices (for TFE readability)
    level1 = _compute_basic_features(close)
    level2 = _compute_trend_curvature(close)

    # Returns for drawdown
    returns = _safe_pct_change(close)
    max_dd = _max_drawdown(returns)

    # Stability metrics from L3/L4
    stab = _compute_stability_from_l4(resonance_results, decision_states)

    # Composite UF metrics S_UF, R_UF (simplified proxies):
    #  - S_UF: use stability of DSF & directional as a structural health score
    #  - R_UF: use mean resonance magnitude
    S_UF = float(max(0.0, min(1.0, 0.5 * stab["dsf"] + 0.5 * stab["directional"])))
    R_UF = float(max(0.0, min(1.0, stab["R_mean"])))

    composite_metrics = {"S_UF": S_UF, "R_UF": R_UF}
    stability_scores = {
        "dsf": stab["dsf"],
        "directional": stab["directional"],
        "hysteresis_rate": stab["hysteresis_rate"],
        "breathing_rate": stab["breathing_rate"],
        "uncertainty_rate": stab["uncertainty_rate"],
        "gate_drift_rate": stab["gate_drift_rate"],
    }
    sensitivity_data: List[Dict[str, float]] = []  # not used yet

    # --------------------------------------------------------
    # 4) Hardening + SafeMode (strict Option 3)
    # --------------------------------------------------------

    safemode_state = init_safemode_state()
    dsf_after, gates_after, safemode_state, htc_result = hardening_control_step(
        current_step=0,
        dsf_list=dsf_list,
        gates=gates,
        composite_metrics=composite_metrics,
        stability_scores=stability_scores,
        sensitivity_data=sensitivity_data,
        safemode_state=safemode_state,
    )

    # If SafeMode or Hardening altered DSF, we use dsf_after for Level5
    final_dsf_list = dsf_after

    # For TFE view, we'll use the last DSF as the current structural decision state
    if final_dsf_list:
        last_dsf = final_dsf_list[-1]
        decision_vector = [
            float(last_dsf.D_k),
            float(last_dsf.M_k),
            float(last_dsf.R_rev_k),
            float(last_dsf.U_star_k),
            float(last_dsf.P_k),
            float(last_dsf.B_k),
        ]
    else:
        decision_vector = []

    # Stability score exposed to TFE: use a simple function of DSF/directional stability & max_drawdown
    stability_score = float(
        max(0.0, min(1.0, 0.5 * stab["dsf"] + 0.3 * stab["directional"] - 2.0 * abs(max_dd)))
    )

    level3 = {"regime": regime}
    level4 = {
        "max_drawdown": max_dd,
        "stability_score": stability_score,
        "S_UF": S_UF,
        "R_UF": R_UF,
    }
    level5 = {
        "decision_vector": decision_vector,
        "dsf_list": [
            {
                "gate": {"start_idx": dsf.gate.start_idx, "end_idx": dsf.gate.end_idx},
                "D_k": dsf.D_k,
                "M_k": dsf.M_k,
                "R_rev_k": dsf.R_rev_k,
                "U_star_k": dsf.U_star_k,
                "P_k": dsf.P_k,
                "B_k": dsf.B_k,
            }
            for dsf in final_dsf_list
        ],
        "hardening": {
            "flags": vars(htc_result.flags),
            "raw_metrics": htc_result.raw_metrics,
            "notes": htc_result.notes,
        },
        "safemode": {
            "safe_mode": safemode_state.safe_mode,
            "entry_step": safemode_state.entry_step,
            "entry_reasons": safemode_state.entry_reasons,
        },
    }

    return UFStructuralState(
        level1=level1,
        level2=level2,
        level3=level3,
        level4=level4,
        level5=level5,
    )
