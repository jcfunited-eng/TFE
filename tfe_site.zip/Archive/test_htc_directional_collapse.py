"""
Test for Hardening Trigger Condition HTC-2 (Directional Collapse).

We provide a simulated stability_scores dict with:
    dsf          = 0.5   (above DSF collapse threshold)
    directional  = 0.2   (below DIR_STABILITY_MIN = 0.4)

Expected:
    flags.dsf_collapse == False
    flags.directional_collapse == True
    raw_metrics['directional_stability'] == 0.2
    notes contains 'Directional stability below threshold (0.4)'
"""

import os
import sys

# Ensure project root is visible
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = current_dir
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from uf_core.hardening import evaluate_htc, HardeningEvaluationResult, KernelStatusFlags


def main():
    stability_scores = {
        "dsf": 0.5,
        "directional": 0.2,
    }

    result = evaluate_htc(stability_scores=stability_scores)

    print("HTC-2 Directional Collapse Test Result:")
    print(result)

    print("\nFlags:", result.flags)
    print("Raw metrics:", result.raw_metrics)
    print("Notes:", result.notes)

    print("\nExplicit Checks:")
    print("DSF Collapse Flag (should be False):", result.flags.dsf_collapse)
    print("Directional Collapse Flag (should be True):", result.flags.directional_collapse)
    print("Stored Directional Stability:", result.raw_metrics.get("directional_stability"))
    print(
        "Has directional collapse note:",
        any("Directional stability below threshold" in note for note in result.notes),
    )


if __name__ == "__main__":
    main()
