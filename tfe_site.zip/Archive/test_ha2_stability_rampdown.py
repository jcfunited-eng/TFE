"""
Test for Hardening Action HA-2 (Stability Ramp-Down, φ = 0.25).

This test validates that:
- When any hardening flag is raised, DSF structural/action signals are scaled by φ = 0.25:
    D_k, M_k, R_rev_k, P_k, B_k → φ * original
    U*_k remains unchanged.

- When NO hardening flags are raised, DSF entries are returned unchanged.
"""

import os
import sys

# Ensure project root is importable
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = current_dir
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from uf_core.hardening import (
    KernelStatusFlags,
    HardeningEvaluationResult,
)
from uf_core.layer4 import DSF
from uf_core.hardening_actions import apply_stability_rampdown


def make_sample_dsf():
    """Return a list of sample DSF entries with non-zero values."""
    return [
        DSF(
            gate=None,
            D_k=1.0,
            M_k=2.0,
            R_rev_k=3.0,
            U_star_k=0.80,
            P_k=4.0,
            B_k=5.0,
        ),
        DSF(
            gate=None,
            D_k=-2.0,
            M_k=-3.0,
            R_rev_k=-4.0,
            U_star_k=0.60,
            P_k=-5.0,
            B_k=-6.0,
        ),
    ]


def main():
    print("=== HA-2 Stability Ramp-Down Test ===\n")

    # ----------------------------------------------------------
    # Case 1: Flags raised → ramp-down MUST occur
    # ----------------------------------------------------------

    dsf_list = make_sample_dsf()

    flags = KernelStatusFlags(
        directional_collapse=True,  # treat as justification for ramp-down
    )
    htc_result = HardeningEvaluationResult(
        flags=flags,
        raw_metrics={},
        notes=[],
    )

    damped = apply_stability_rampdown(htc_result, dsf_list)

    print("Damped DSF list (flags active):")
    for dsf in damped:
        print(dsf)

    print("\nExplicit Checks (ramp-down case):")
    φ = 0.25
    for i, (orig, dsf) in enumerate(zip(dsf_list, damped)):
        print(
            f"Entry {i}: "
            f"D: {orig.D_k} -> {dsf.D_k}, "
            f"M: {orig.M_k} -> {dsf.M_k}, "
            f"R_rev: {orig.R_rev_k} -> {dsf.R_rev_k}, "
            f"P: {orig.P_k} -> {dsf.P_k}, "
            f"B: {orig.B_k} -> {dsf.B_k}, "
            f"U*: {orig.U_star_k} -> {dsf.U_star_k}"
        )

    # ----------------------------------------------------------
    # Case 2: No flags → NO ramp-down
    # ----------------------------------------------------------

    flags2 = KernelStatusFlags()  # all False
    htc_result2 = HardeningEvaluationResult(
        flags=flags2,
        raw_metrics={},
        notes=[],
    )

    unchanged = apply_stability_rampdown(htc_result2, dsf_list)

    print("\nUnchanged DSF list (no flags):")
    for dsf in unchanged:
        print(dsf)

    print("\nExplicit Checks (no-ramp-down case):")
    for i, (orig, dsf) in enumerate(zip(dsf_list, unchanged)):
        print(
            f"Entry {i}: "
            f"D: {orig.D_k} -> {dsf.D_k}, "
            f"M: {orig.M_k} -> {dsf.M_k}, "
            f"R_rev: {orig.R_rev_k} -> {dsf.R_rev_k}, "
            f"P: {orig.P_k} -> {dsf.P_k}, "
            f"B: {orig.B_k} -> {dsf.B_k}, "
            f"U*: {orig.U_star_k} -> {dsf.U_star_k}"
        )


if __name__ == "__main__":
    main()
