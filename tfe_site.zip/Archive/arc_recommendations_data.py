# recommendations_data.py

HIGH_POTENTIAL = [
    {"Ticker": "NVDA", "Reason": "AI + datacenter leadership"},
    {"Ticker": "SMCI", "Reason": "High-growth server infrastructure"},
    {"Ticker": "SOXX", "Reason": "Semiconductor momentum ETF"},
    {"Ticker": "QQQM", "Reason": "Tech-heavy growth broad ETF"},
]

MEDIUM_POTENTIAL = [
    {"Ticker": "AAPL", "Reason": "Mega-cap stable growth"},
    {"Ticker": "MSFT", "Reason": "Cloud + AI ecosystem strength"},
    {"Ticker": "COST", "Reason": "Retail compounder"},
    {"Ticker": "SCHD", "Reason": "Dividend + growth balance"},
]

LOW_POTENTIAL = [
    {"Ticker": "VOO", "Reason": "S&P 500 broad stability"},
    {"Ticker": "VXUS", "Reason": "International diversification"},
    {"Ticker": "BND", "Reason": "Bond exposure / low volatility"},
    {"Ticker": "JEPI", "Reason": "Income-focused ETF"},
]

def get_recommendations():
    return {
        "High": HIGH_POTENTIAL,
        "Medium": MEDIUM_POTENTIAL,
        "Low": LOW_POTENTIAL
    }
