"""
Simple structural test for UF Hardening KernelStatusFlags.

This script:
- Instantiates the KernelStatusFlags container.
- Prints its default values.
"""

import os
import sys

# Ensure project root is on sys.path
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = current_dir  # test is in project root
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from uf_core.hardening import kernel_status_flags


def main():
    flags = kernel_status_flags()
    print("KernelStatusFlags default instance:")
    print(flags)


if __name__ == "__main__":
    main()
