"""
Test SafeMode entry behavior under strict severe-collapse policy.

Scenarios:
1) No severe flags → no SafeMode.
2) dsf_collapse=True with no prior frozen gates → SafeMode enters, snapshotting current_gates.
3) gate_drift_excess=True with existing frozen_gates → SafeMode preserves existing frozen snapshot.
"""

import os
import sys

# Ensure project root on sys.path
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = current_dir
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from uf_core.hardening import KernelStatusFlags, HardeningEvaluationResult
from uf_core.layer1 import Gate
from uf_core.safemode import (
    SafeModeState,
    init_safemode_state,
    enter_safemode,
)


def make_gates_a():
    return [
        Gate(start_idx=0, end_idx=10),
        Gate(start_idx=11, end_idx=20),
    ]


def make_gates_b():
    return [
        Gate(start_idx=0, end_idx=5),
        Gate(start_idx=6, end_idx=15),
    ]


def main():
    print("=== SafeMode Entry Test ===\n")

    # ----------------------------------------------------------
    # Case 1: No severe flags → no SafeMode
    # ----------------------------------------------------------
    gates_a = make_gates_a()
    flags1 = KernelStatusFlags()  # all False
    htc_result1 = HardeningEvaluationResult(flags=flags1, raw_metrics={}, notes=[])

    state1 = enter_safemode(
        htc_result=htc_result1,
        current_step=10,
        current_gates=gates_a,
        composite_metrics={"S_UF": 0.6, "R_UF": 0.2},
        stability_scores={"dsf": 0.5},
        current_state=None,
    )

    print("Case 1 — No severe flags:")
    print(state1)

    # ----------------------------------------------------------
    # Case 2: dsf_collapse=True, no prior frozen_gates
    # ----------------------------------------------------------
    flags2 = KernelStatusFlags(dsf_collapse=True)
    htc_result2 = HardeningEvaluationResult(
        flags=flags2,
        raw_metrics={"dsf_stability": 0.1},
        notes=["DSF stability below threshold"],
    )

    state2 = enter_safemode(
        htc_result=htc_result2,
        current_step=20,
        current_gates=gates_a,
        composite_metrics={"S_UF": 0.4, "R_UF": 0.1},
        stability_scores={"dsf": 0.1},
        current_state=None,
    )

    print("\nCase 2 — dsf_collapse=True, no prior frozen_gates:")
    print(state2)
    print("Frozen gates snapshot:")
    for g in state2.frozen_gates:
        print(g)

    # ----------------------------------------------------------
    # Case 3: gate_drift_excess=True, existing frozen_gates
    # ----------------------------------------------------------
    gates_b = make_gates_b()
    flags3 = KernelStatusFlags(gate_drift_excess=True)
    htc_result3 = HardeningEvaluationResult(
        flags=flags3,
        raw_metrics={"gate_drift_rate": 0.6},
        notes=["Gate drift rate above threshold (0.25)"],
    )

    # Use state2 as previous SafeModeState, which already has frozen_gates from gates_a
    state3 = enter_safemode(
        htc_result=htc_result3,
        current_step=30,
        current_gates=gates_b,
        composite_metrics={"S_UF": 0.45, "R_UF": 0.12},
        stability_scores={"dsf": 0.2},
        current_state=state2,
    )

    print("\nCase 3 — drift_excess=True, existing frozen_gates (must preserve old snapshot):")
    print(state3)
    print("Frozen gates preserved:")
    for g in state3.frozen_gates:
        print(g)


if __name__ == "__main__":
    main()
