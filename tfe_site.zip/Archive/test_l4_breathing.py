import pandas as pd

from uf_core.layer0 import compute_sev_series
from uf_core.layer1 import segment_gates
from uf_core.layer2 import interpret_gates
from uf_core.layer3 import compute_resonance
from uf_core.layer4 import compute_directional_signal


def main():
    prices = [100, 101, 102, 110, 111, 112, 113, 90, 91, 92, 93, 94]
    df = pd.DataFrame({"Close": prices})

    sev_list = compute_sev_series(df)
    gates = segment_gates(sev_list)
    interpretations = interpret_gates(sev_list, gates)
    resonance_results = compute_resonance(interpretations)
    decision_states = compute_directional_signal(resonance_results)

    print("Total gates:", len(decision_states))
    print("Breathing rule: B_k = +1 if P_k=+1 and P_{k-1}=-1; "
          "B_k=-1 if P_k=-1 and P_{k-1}=+1; else 0.\n")

    prev_P = None

    for idx, ds in enumerate(decision_states, start=1):
        res = ds.resonance_result
        gate = res.interpretation.gate

        P_k = ds.P_k
        B_k = ds.B_k

        # Expected B_k using the definition
        if prev_P is None:
            expected = 0
        else:
            if P_k == 1 and prev_P == -1:
                expected = 1
            elif P_k == -1 and prev_P == 1:
                expected = -1
            else:
                expected = 0

        print(f"Gate {idx}:")
        print(f" Index range = [{gate.start_idx}, {gate.end_idx}]")
        print(f" P_k         = {P_k}")
        print(f" B_k         = {B_k}")
        print(f" Expected B_k= {expected}\n")

        prev_P = P_k


if __name__ == "__main__":
    main()
