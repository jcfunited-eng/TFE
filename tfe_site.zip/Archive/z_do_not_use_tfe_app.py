import streamlit as st
import pandas as pd
import plotly.graph_objects as go

import data_loader
import portfolio
import risk
import market as mkt    # sma, ema, macd, bollinger, rsi, momentum

def normalize_asset_type(value):
    if not isinstance(value, str):
        return "other"
    v = value.strip().lower()
    if v in ["equity", "stock", "etf", "shares"]:
        return "equity"
    if v in ["crypto", "cryptocurrency"]:
        return "crypto"
    if v in ["index", "^gspc", "^ixic"]:
        return "index"
    return "other"

def classify_asset_type(ticker):
    if ticker.endswith("-USD"):
        return "crypto"
    if ticker.startswith("^"):
        return "index"
    return "equity"

# ===================================================
# PAGE SETUP
# ===================================================

st.set_page_config(
    page_title="Tao Financial Engine",
    layout="wide",
)

PLOTLY_TEMPLATE = "plotly_dark"
UP_COLOR = "#00B050"
DOWN_COLOR = "#C00000"


# ===================================================
# PORTFOLIO LOADING & NORMALIZATION
# ===================================================

def get_portfolio_and_prices():
    """
    Loads portfolio.csv and returns:
      - positions: DataFrame with ticker, quantity, cost_basis, asset_type
      - tickers: list of tickers
      - latest_prices: dict[ticker → price]
      - snapshot: portfolio snapshot object (from your portfolio.py)
    """

    df = pd.read_csv("portfolio.csv")

    # Normalize names
    df.columns = [c.lower().strip() for c in df.columns]

    required = {"ticker", "quantity", "cost_basis"}
    if not required.issubset(df.columns):
        raise ValueError("portfolio.csv must have at least: ticker, quantity, cost_basis")

    # Keep asset_type if present
    if "asset_type" not in df.columns:
        df["asset_type"] = None

    positions = df[["ticker", "quantity", "cost_basis", "asset_type"]].copy()
    tickers = list(positions["ticker"])

    latest = data_loader.latest_prices(tickers)
    snapshot = portfolio.compute_portfolio_snapshot(positions, latest)

    return positions, tickers, latest, snapshot


# ===================================================
# PRICE HISTORY + INDICATORS
# ===================================================

@st.cache_data(show_spinner=False)
def get_history_with_indicators(ticker, period="6mo", interval="1d"):
    """
    Loads price history + computes indicators.
    ALWAYS returns:
      df  - dataframe with open/high/low/close/volume
      ind - dict with indicators (vol, sharpe, rsi, macd, bb, max_dd, etc)
    """
    try:
        df = data_loader.load_price_history(ticker)
    except Exception:
        return pd.DataFrame(), {}

    if df.empty:
        return pd.DataFrame(), {}

    df = df.sort_index()
    close = df["close"]

    # ------------------------- Indicators -------------------------
    sma20 = mkt.sma(close, 20)
    ema20 = mkt.ema(close, 20)

    bb_mid, bb_up, bb_low = mkt.bollinger_bands(close, 20, 2.0)
    rsi14 = mkt.rsi(close, 14)
    macd_line, macd_signal = mkt.macd(close)
    momentum10 = mkt.momentum(close, 10)

    # Risk metrics
    rets = risk.daily_returns(close)
    vol = risk.annualized_volatility(rets)
    sharpe = risk.sharpe_ratio(rets, 0.02)

    # ------------------------- MAX DRAWDOWN -------------------------
    try:
        equity_curve = (1 + rets).cumprod()
        max_dd_val, _ = risk.max_drawdown(equity_curve)
    except Exception:
        max_dd_val = 0.0

    # ------------------------- PACK INDICATORS -------------------------
    ind = {
        "close": close,
        "sma_20": sma20,
        "ema_20": ema20,
        "bb_mid": bb_mid,
        "bb_up": bb_up,
        "bb_low": bb_low,
        "rsi_14": rsi14,
        "macd_line": macd_line,
        "macd_signal": macd_signal,
        "momentum_10": momentum10,
        "volatility": float(vol) if not pd.isna(vol) else 0.2,
        "sharpe": float(sharpe) if not pd.isna(sharpe) else 0.0,
        "max_dd": float(max_dd_val) if not pd.isna(max_dd_val) else 0.0
    }

    return df, ind

# ===================================================
# TICKER HISTORY RANGE HELPER
# ===================================================

def get_history_range(ticker, range_code):
    """
    Returns a (period, interval) pair to send to yfinance.
    """
    mapping = {
        "1D": ("1d", "1m"),
        "5D": ("5d", "5m"),
        "1M": ("1mo", "30m"),
        "6M": ("6mo", "1d"),
        "YTD": ("ytd", "1d"),
        "1Y": ("1y", "1d"),
        "5Y": ("5y", "1wk"),
        "MAX": ("max", "1mo"),
    }
    return mapping.get(range_code, ("6mo", "1d"))

# ===================================================
# UTILITY FUNCTIONS
# ===================================================

def normalize_df(df):
    """Ensure DataFrame has a datetime index as 'date'."""
    df2 = df.copy()
    df2["date"] = pd.to_datetime(df2.index)
    return df2.set_index("date").sort_index()


def classify_asset_type(ticker):
    """Categorize by ticker format."""
    if ticker.endswith("-USD"):
        return "crypto"
    if ticker.startswith("^"):
        return "index"
    return "equity"

# >>> ADD THIS BELOW classify_asset_type <<<
def normalize_asset_type(value):
    if not isinstance(value, str):
        return "other"
    v = value.strip().lower()
    if v in ["equity", "stock", "etf", "shares"]:
        return "equity"
    if v in ["crypto", "cryptocurrency"]:
        return "crypto"
    if v in ["index", "^gspc", "^ixic"]:
        return "index"
    return "other"

def render_indicator_summary(ind):
    """Render volatility, Sharpe, RSI, max drawdown in a clean T2 tone."""
    vol = ind["volatility"]
    sharpe = ind["sharpe"]
    max_dd = ind["max_dd"]
    rsi_series = ind["rsi_14"]
    rsi_val = rsi_series.iloc[-1] if not rsi_series.dropna().empty else None

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Volatility", f"{vol:.2%}")
    c2.metric("Sharpe (2% RF)", f"{sharpe:.2f}")
    c3.metric("Max Drawdown", f"{max_dd:.2%}")
    c4.metric("RSI (14)", f"{rsi_val:.1f}" if rsi_val else "N/A")

    st.write("")

    # Interpretation (T2 tone)
    if rsi_val:
        if rsi_val > 70:
            st.write("• RSI indicates overbought levels.")
        elif rsi_val < 30:
            st.write("• RSI indicates oversold levels.")
        else:
            st.write("• RSI is neutral.")

    if sharpe > 1:
        st.write("• Strong risk-adjusted return.")
    elif sharpe < 0:
        st.write("• Weak or negative risk-adjusted return.")
    else:
        st.write("• Risk-adjusted return is neutral.")
def render_charts(ticker, df, ind):
    """Plot candlestick + indicators using Plotly."""
    dfc = normalize_df(df)

    sma = ind["sma_20"]
    ema = ind["ema_20"]
    bb_mid = ind["bb_mid"]
    bb_up = ind["bb_up"]
    bb_low = ind["bb_low"]
    rsi = ind["rsi_14"]
    macd_line = ind["macd_line"]
    macd_signal = ind["macd_signal"]
    mom = ind["momentum_10"]

    # PRICE CHART
    st.subheader(f"Price & Trend — {ticker}")
    fig_price = go.Figure()

    fig_price.add_trace(go.Candlestick(
        x=dfc.index,
        open=dfc["open"],
        high=dfc["high"],
        low=dfc["low"],
        close=dfc["close"],
        increasing_line_color=UP_COLOR,
        decreasing_line_color=DOWN_COLOR,
    ))

    fig_price.add_trace(go.Scatter(
        x=dfc.index, y=sma, name="SMA 20",
        line=dict(color="#FFD700")
    ))
    fig_price.add_trace(go.Scatter(
        x=dfc.index, y=ema, name="EMA 20",
        line=dict(color="#4a90e2")
    ))
    fig_price.add_trace(go.Scatter(
        x=dfc.index, y=bb_up, name="BB Upper",
        line=dict(color="#AAAAAA", dash="dot")
    ))
    fig_price.add_trace(go.Scatter(
        x=dfc.index, y=bb_mid, name="BB Middle",
        line=dict(color="#888888", dash="dot")
    ))
    fig_price.add_trace(go.Scatter(
        x=dfc.index, y=bb_low, name="BB Lower",
        line=dict(color="#AAAAAA", dash="dot")
    ))

    fig_price.update_layout(template=PLOTLY_TEMPLATE)
    st.plotly_chart(fig_price, use_container_width=True)

    # MOMENTUM
    st.subheader("Momentum")
    fig_mom = go.Figure()
    fig_mom.add_trace(go.Scatter(
        x=dfc.index, y=mom,
        line=dict(color="#4a90e2")
    ))
    fig_mom.update_layout(template=PLOTLY_TEMPLATE)
    st.plotly_chart(fig_mom, use_container_width=True)

    # RSI
    st.subheader("RSI (14)")
    fig_rsi = go.Figure()
    fig_rsi.add_trace(go.Scatter(
        x=dfc.index, y=rsi,
        line=dict(color="#4a90e2")
    ))
    fig_rsi.add_hline(y=70, line_color="red", line_dash="dot")
    fig_rsi.add_hline(y=30, line_color="green", line_dash="dot")
    fig_rsi.update_layout(template=PLOTLY_TEMPLATE)
    st.plotly_chart(fig_rsi, use_container_width=True)

    # MACD
    st.subheader("MACD")
    fig_macd = go.Figure()
    fig_macd.add_trace(go.Scatter(
        x=dfc.index, y=macd_line,
        line=dict(color="#4a90e2")
    ))
    fig_macd.add_trace(go.Scatter(
        x=dfc.index, y=macd_signal,
        line=dict(color="#AAAAAA", dash="dot")
    ))
    fig_macd.update_layout(template=PLOTLY_TEMPLATE)
    st.plotly_chart(fig_macd, use_container_width=True)


# ===================================================
# SIMPLE RECOMMENDATION ENGINE
# ===================================================

@st.cache_data(show_spinner=False)
def build_recommendations(positions: pd.DataFrame):
    """
    Uses a small universe:
      - all portfolio tickers
      - plus a fixed watchlist
    and scores them based on momentum, Sharpe, volatility, RSI.
    Returns: (actions_list, df_high, df_medium, df_low)
    """

    portfolio_tickers = list(positions["ticker"])
    watchlist = [
        "AAPL", "MSFT", "NVDA", "VTI", "VOO", "SPY",
        "^GSPC", "^IXIC", "BTC-USD", "ETH-USD",
    ]
    universe = sorted(set(portfolio_tickers + watchlist))

    rows = []

    for ticker in universe:
        try:
            df, ind = get_history_with_indicators(ticker)
        except Exception:
            continue

        vol = ind["volatility"]
        sharpe = ind["sharpe"]
        max_dd = ind["max_dd"]
        rsi = ind["rsi_14"].iloc[-1] if not ind["rsi_14"].dropna().empty else None
        mom = ind["momentum_10"].iloc[-1] if not ind["momentum_10"].dropna().empty else None

        score = 0.0
        notes = []

        # momentum
        if mom is not None:
            if mom > 0.05:
                score += 2
                notes.append("strong positive momentum")
            elif mom > 0:
                score += 1
                notes.append("mild positive momentum")
            elif mom < -0.05:
                score -= 1
                notes.append("negative momentum")

        # sharpe
        if sharpe > 1:
            score += 2
            notes.append("good risk-adjusted return")
        elif sharpe > 0:
            score += 1
            notes.append("mild risk-adjusted return")
        else:
            score -= 1
            notes.append("weak risk-adjusted return")

        # volatility
        if vol < 0.15:
            score += 1
            notes.append("low volatility")
        elif vol > 0.4:
            score -= 1
            notes.append("high volatility")

        # RSI
        if rsi:
            if 40 <= rsi <= 60:
                score += 1
                notes.append("RSI neutral")
            elif rsi < 30:
                notes.append("RSI oversold")
            elif rsi > 70:
                score -= 1
                notes.append("RSI overbought")

        asset_type = classify_asset_type(ticker)

        rows.append({
            "ticker": ticker,
            "asset_type": asset_type,
            "score": score,
            "volatility": vol,
            "sharpe": sharpe,
            "max_dd": max_dd,
            "notes": "; ".join(notes),
        })

    if not rows:
        return [], pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

    all_df = pd.DataFrame(rows).sort_values("score", ascending=False)

    high = all_df[all_df["score"] >= 3].head(3)
    medium = all_df[(all_df["score"] >= 1) & (all_df["score"] < 3)].head(5)
    low = all_df[all_df["score"] < 1].head(5)

    # ---- Portfolio actions ----
    actions = []
    if not positions.empty:
        _, _, latest, snap = get_portfolio_and_prices()
        weights = snap.weights

        for _, row in positions.iterrows():
            t = row["ticker"]
            w = weights.get(t, 0)
            asset_type = classify_asset_type(t)

            try:
                _, ind = get_history_with_indicators(t)
            except Exception:
                continue

            v = ind["volatility"]
            s = ind["sharpe"]

            if w > 0.40:
                action = "Trim slightly (overweight)."
            elif s > 1 and v < 0.25:
                action = "Hold. Trend and risk look stable."
            elif s > 0 and v < 0.30:
                action = "Hold or add slowly if you are investing new funds."
            elif s < 0:
                action = "Hold cautiously. Consider reviewing this position."
            else:
                action = "Hold. No strong signal."

            if asset_type == "crypto" and v > 0.40:
                action += " Crypto volatility is high; avoid large changes."

            actions.append({
                "ticker": t,
                "weight": w,
                "asset_type": asset_type,
                "action": action,
                "volatility": v,
                "sharpe": s,
            })

    return actions, high, medium, low

# ===================================================
# DASHBOARD PAGE
# ===================================================

def render_dashboard():
    st.title("📊 Tao Financial Engine — Dashboard")

    positions, tickers, latest, snap = get_portfolio_and_prices()

    # Summary metrics
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Total Value", f"${snap.total_value:,.2f}")
    c2.metric("Unrealized P/L", f"{snap.unrealized_pl:,.2f}", f"{snap.unrealized_pl_pct:.2%}")
    c3.metric("Diversification", f"{snap.diversification_score:.2f}")
    c4.metric("Assets", len(snap.weights))

    # Weights
    st.subheader("Portfolio Weights")
    st.json(snap.weights)

    # Latest prices
    st.subheader("Latest Prices")
    st.json(latest)

    # Per-asset risk summary
    st.subheader("Asset Risk Overview")
    for t in tickers:
        st.markdown(f"### {t}")
        df, ind = get_history_with_indicators(t)
        render_indicator_summary(ind)
        st.markdown("---")

# ===================================================
# LOOKUP PAGE
# ===================================================

def render_lookup():
    st.title("🔍 Ticker Lookup — Multi-Chart Insight")

    ticker = st.text_input(
        "Enter ticker (AAPL, BTC-USD, VTI, ^GSPC):",
        "AAPL"
    ).upper().strip()

    if not ticker:
        return

    # Load full history
    try:
        df_full = data_loader.load_price_history(ticker)
        df_full.index = pd.to_datetime(df_full.index, utc=True).tz_convert(None)

    except Exception:
        st.error("Unable to load historical data for this ticker.")
        return

    if df_full.empty:
        st.error("No historical data available for this ticker.")
        return

    df_full = df_full.sort_index()

    # Date range selector
    range_choice = st.selectbox(
        "Date Range",
        ["1D", "5D", "1M", "6M", "YTD", "1Y", "5Y", "MAX"],
        index=3
    )

    # Map range -> number of rows
    n = len(df_full)

    if range_choice == "1D":
        df = df_full.tail(1)

    elif range_choice == "5D":
        df = df_full.tail(5)

    elif range_choice == "1M":
        df = df_full.tail(21)

    elif range_choice == "6M":
        df = df_full.tail(126)

    elif range_choice == "1Y":
        df = df_full.tail(252)

    elif range_choice == "5Y":
        df = df_full.tail(252 * 5)

    elif range_choice == "YTD":
        start = pd.Timestamp(datetime.now().year, 1, 1)
        df = df_full[df_full.index >= start]

    else:   # MAX
        df = df_full.copy()

    if df.empty:
        st.error("No data available for this date range.")
        return

    # Indicators
    close = df["close"]
    sma_20 = mkt.sma(close, 20)
    ema_20 = mkt.ema(close, 20)
    bb_mid, bb_up, bb_low = mkt.bollinger_bands(close, 20, 2.0)
    rsi_14 = mkt.rsi(close, 14)
    macd_line, macd_signal = mkt.macd(close)
    mom_10 = mkt.momentum(close, 10)
    rets = risk.daily_returns(close)
    vol = risk.annualized_volatility(rets)
    sharpe = risk.sharpe_ratio(rets, 0.02)
    equity = (1 + rets).cumprod() * 10000
    max_dd, dd_days = risk.max_drawdown(equity)

    ind = {
        "sma_20": sma_20,
        "ema_20": ema_20,
        "bb_mid": bb_mid,
        "bb_up": bb_up,
        "bb_low": bb_low,
        "rsi_14": rsi_14,
        "macd_line": macd_line,
        "macd_signal": macd_signal,
        "momentum_10": mom_10,
        "volatility": vol,
        "sharpe": sharpe,
        "max_dd": max_dd,
    }

    st.subheader("Indicators & Risk")
    render_indicator_summary(ind)

    render_charts(ticker, df, ind)
# ===================================================
# RECOMMENDATIONS PAGE — BUY / HOLD / REDUCE
# ===================================================

def render_recommendations():

    st.title("⭐ Market Recommendations — Buy / Hold / Reduce")

    # ----- LOAD PORTFOLIO + MARKET UNIVERSE -----
    positions, tickers, latest, snapshot = get_portfolio_and_prices()

    universe = list(set(tickers + [
        "AAPL","VTI","QQQ","MSFT","GOOGL","AMZN","META","TSLA","NVDA",
        "JPM","UNH","HD","XOM","CVX","BAC","KO","PEP","NFLX","IWM","VOO",
        "BTC-USD","ETH-USD"
    ]))

    prices = data_loader.latest_prices(universe)

    # Build market dataframe
    market_df = pd.DataFrame([
        {"Ticker": t, "Price": prices.get(t)}
        for t in universe if prices.get(t) is not None
    ])

    if market_df.empty:
        st.error("Unable to load market prices.")
        return

    # ----- PRICE TIERS -----
    q30 = market_df["Price"].quantile(0.30)
    q70 = market_df["Price"].quantile(0.70)

    def tier_label(p):
        if p <= q30: return "Low Price Tier"
        if p <= q70: return "Mid Price Tier"
        return "High Price Tier"

    market_df["Tier"] = market_df["Price"].apply(tier_label)

# ------ BUILD RECOMMENDATIONS ------
results = []

# Create tier lookup (to ensure correct Low/Mid/High from market_df)
tier_map = dict(zip(market_df["Ticker"], market_df["Tier"]))

for t in market_df["Ticker"]:
    df, ind = get_history_with_indicators(t)

    # Skip tickers with missing history
    if ind == {} or df.empty:
        continue

    close = ind["close"]
    price = float(close.iloc[-1])

    # Trend 20d
    if len(close) > 20:
        trend20 = (close.iloc[-1] - close.iloc[-21]) / close.iloc[-21]
    else:
        trend20 = 0.0

    # Safe RSI
    rsi_series = ind.get("rsi_14", None)
    rsi = float(rsi_series.iloc[-1]) if rsi_series is not None else 50.0

    # Safe Sharpe + Volatility
    sharpe = float(ind.get("sharpe", 0.0))
    vol = float(ind.get("volatility", 0.2))

    # ------------ MULTI-FACTOR SCORE ------------
    score = 0
    if trend20 > 0.05: score += 2
    if trend20 < -0.05: score -= 2
    if rsi < 30: score += 2
    if rsi > 70: score -= 2
    if sharpe > 1.0: score += 1
    if sharpe < 0.3: score -= 1
    score -= vol

    # Decision
    if score >= 2:
        decision = "BUY"
    elif score <= -2:
        decision = "REDUCE"
    else:
        decision = "HOLD"

    # Asset Type
    if "-USD" in t:
        asset_type = "crypto"
    elif t in ["VTI", "VOO", "QQQ", "IWM"]:
        asset_type = "etf"
    elif t.startswith("^"):
        asset_type = "index"
    else:
        asset_type = "equity"

    # USE market_df tier value (Low/Mid/High) — this was the missing key!
    tier_value = tier_map.get(t, tier_label(price))

    results.append({
        "Ticker": t,
        "Asset Type": asset_type,
        "Price": round(price, 2),
        "Tier": tier_value,
        "Trend20d %": round(trend20 * 100, 2),
        "RSI": round(rsi, 1),
        "Sharpe": round(sharpe, 2),
        "Volatility": round(vol, 2),
        "Decision": decision,
        "Score": round(score, 2),
    })

# ------ FINAL RECS DF ------
recs_df = pd.DataFrame(results).sort_values("Score", ascending=False)

    # ============================================================
    # 🔥 HOT PICKS — Promising Under $30 (Buy Only)
    # ============================================================
    st.subheader("🔥 HOT PICKS — Promising Under $30")

    hot_results = []

    for asset in ["equity", "etf", "index", "crypto"]:
        subset = recs_df[
            (recs_df["Asset Type"] == asset) &
            (recs_df["Price"] < 30) &
            (recs_df["Decision"] == "BUY")
        ]

        top3 = subset.sort_values("Score", ascending=False).head(3)

        if not top3.empty:
            hot_results.append((asset.upper(), top3))

    if not hot_results:
        st.info("No strong BUY-rated sub-$30 candidates today.")
    else:
        for label, df_hot in hot_results:
            st.write(f"### {label} — Top Picks Under $30")
            st.dataframe(
                df_hot[["Ticker","Price","Score","Trend20d %","RSI","Sharpe"]],
                use_container_width=True
            )

    # ============================================================
    # ⭐ Recommendations by Price Tier
    # ============================================================
    st.subheader("🟦 Recommendations by Price Tier")

    tier_choice = st.selectbox(
        "Select Tier:",
        ["Low Price Tier", "Mid Price Tier", "High Price Tier"]
    )

    tier_df = recs_df[recs_df["Tier"] == tier_choice]

    if tier_df.empty:
        st.info("No recommendations available for this tier.")
    else:
        st.dataframe(
            tier_df[[ 
                "Ticker","Asset Type","Price","Tier",
                "Trend20d %","RSI","Sharpe","Volatility","Decision","Score"
            ]],
            use_container_width=True
        )
    # ============================================================
    # 🔥 HOT PICKS — Promising Under $30 (Buy Only)
    # ============================================================
    st.subheader("🔥 HOT PICKS — Promising Under $30")

    hot_results = []

    for asset in ["equity", "etf", "index", "crypto"]:
        subset = recs_df[
            (recs_df["Asset Type"] == asset) &
            (recs_df["Price"] < 30) &
            (recs_df["Decision"] == "BUY")
        ]

        top3 = subset.sort_values("Score", ascending=False).head(3)

        if not top3.empty:
            hot_results.append((asset.upper(), top3))

    if not hot_results:
        st.info("No strong BUY-rated sub-$30 candidates today.")
    else:
        for label, df_hot in hot_results:
            st.write(f"### {label} — Top Picks Under $30")
            st.dataframe(
                df_hot[["Ticker","Price","Score","Trend20d %","RSI","Sharpe"]],
                use_container_width=True
            )

    # ============================================================
    # ⭐ Recommendations by Price Tier
    # ============================================================
    st.subheader("🟦 Recommendations by Price Tier")

    tier_choice = st.selectbox(
        "Select Tier:",
        ["Low Price Tier", "Mid Price Tier", "High Price Tier"]
    )

    tier_df = recs_df[recs_df["Tier"] == tier_choice]

    if tier_df.empty:
        st.info("No recommendations available for this tier.")
    else:
        st.dataframe(
            tier_df[[ 
                "Ticker","Asset Type","Price","Tier",
                "Trend20d %","RSI","Sharpe","Volatility","Decision","Score"
            ]],
            use_container_width=True
        )
# ===================================================
# PORTFOLIO MANAGER (Add / Remove / Update)
# ===================================================

# ===================================================
# PORTFOLIO MANAGER (uses the tested standalone logic)
# ===================================================

def render_portfolio_manager():
    st.title("🧺 Portfolio Manager")
    st.write("Add, remove, or update assets in your portfolio (portfolio.csv).")

    # --- helper functions just for this page ---

    def load_portfolio_df() -> pd.DataFrame:
        df = pd.read_csv("portfolio.csv")
        # normalise column names
        df.columns = [c.lower().strip() for c in df.columns]
        # required columns
        required = {"ticker", "quantity", "cost_basis"}
        if not required.issubset(df.columns):
            st.error("portfolio.csv must contain columns: ticker, quantity, cost_basis")
            st.stop()
        # ensure asset_type exists and normalise a few common labels
        if "asset_type" not in df.columns:
            df["asset_type"] = "equity"
        df["asset_type"] = df["asset_type"].apply(
            lambda v: "equity"
            if str(v).lower() in ("stock", "etf", "shares")
            else str(v).lower()
        )
        return df

    def save_portfolio_df(df: pd.DataFrame):
        df.to_csv("portfolio.csv", index=False)

    # load current state
    df = load_portfolio_df()
    tickers = list(df["ticker"])

    # tabs
    tab_add, tab_remove, tab_update = st.tabs(
        ["➕ Add Asset", "🗑 Remove Asset", "✏️ Update Asset"]
    )

    # -------------------------
    # ADD ASSET
    # -------------------------
    with tab_add:
        st.subheader("Add Asset")

        new_ticker = st.text_input("Ticker (e.g., AAPL, BTC-USD)").upper().strip()
        new_qty = st.number_input("Quantity", min_value=0.0, format="%.4f")
        new_cost = st.number_input("Cost basis per unit ($)", min_value=0.0, format="%.4f")

        asset_options = ["equity", "crypto", "index", "other"]
        new_type = st.selectbox("Asset type", asset_options, index=0, key="pm_add_type")

        if st.button("Add to Portfolio", key="pm_add_btn"):
            if not new_ticker:
                st.error("Ticker cannot be empty.")
            else:
                new_row = pd.DataFrame(
                    [{
                        "ticker": new_ticker,
                        "quantity": new_qty,
                        "cost_basis": new_cost,
                        "asset_type": new_type,
                    }]
                )
                df_new = pd.concat([df, new_row], ignore_index=True)
                save_portfolio_df(df_new)
                st.success(f"Added {new_ticker}.")
                st.rerun()

    # -------------------------
    # REMOVE ASSET
    # -------------------------
    with tab_remove:
        st.subheader("Remove Asset")

        if not tickers:
            st.info("Your portfolio is currently empty.")
        else:
            rm_ticker = st.selectbox(
                "Select asset to remove",
                tickers,
                key="pm_remove_select",
            )

            if st.button("Remove Asset", key="pm_remove_btn"):
                df_new = df[df["ticker"] != rm_ticker]
                save_portfolio_df(df_new)
                st.success(f"Removed {rm_ticker}.")
                st.rerun()

    # -------------------------
    # UPDATE ASSET
    # -------------------------
    with tab_update:
        st.subheader("Update Asset")

        if not tickers:
            st.info("Your portfolio is currently empty.")
        else:
            up_ticker = st.selectbox(
                "Select asset",
                tickers,
                key="pm_update_select",
            )

            # select row for that ticker
            row = df[df["ticker"] == up_ticker].iloc[0]

            qty = st.number_input(
                "Quantity",
                min_value=0.0,
                value=float(row["quantity"]),
                format="%.4f",
                key=f"pm_qty_{up_ticker}",
            )
            cost = st.number_input(
                "Cost basis per unit ($)",
                min_value=0.0,
                value=float(row["cost_basis"]),
                format="%.4f",
                key=f"pm_cost_{up_ticker}",
            )

            asset_options = ["equity", "crypto", "index", "other"]
            current_type = str(row["asset_type"]).lower()
            if current_type not in asset_options:
                current_type = "equity"
            type_index = asset_options.index(current_type)

            a_type = st.selectbox(
                "Asset type",
                asset_options,
                index=type_index,
                key=f"pm_type_{up_ticker}",
            )

            if st.button("Save Changes", key=f"pm_save_{up_ticker}"):
                df_new = df.copy()
                df_new.loc[df_new["ticker"] == up_ticker, "quantity"] = qty
                df_new.loc[df_new["ticker"] == up_ticker, "cost_basis"] = cost
                df_new.loc[df_new["ticker"] == up_ticker, "asset_type"] = a_type
                save_portfolio_df(df_new)
                st.success(f"Updated {up_ticker}.")
                st.rerun()

# ===================================================
# PORTFOLIO INSIGHTS  (formerly Mom Mode)
# ===================================================

def render_portfolio_insights():
    st.title("💡 Portfolio Insights")
    st.write("A simplified overview of your portfolio status, opportunities, and risks.")

    try:
        positions, tickers, latest, snap = get_portfolio_and_prices()
        actions, high, medium, low = build_recommendations(positions)
    except Exception as e:
        st.error(f"Error loading portfolio: {e}")
        return

    if positions.empty:
        st.info("Your portfolio is empty. Add assets in the Portfolio Manager.")
        return

    # ---- Determine simple health state ----
    pl_pct = snap.unrealized_pl_pct
    diversification = snap.diversification_score
    avg_vol = sum(a["volatility"] for a in actions) / len(actions)

    # Status logic
    if pl_pct > 0.05 and avg_vol < 0.30:
        status = "GREEN"
        msg = "Portfolio is performing well with manageable risk."
    elif pl_pct < -0.10 or avg_vol > 0.45:
        status = "RED"
        msg = "Elevated risk or recent losses require attention."
    else:
        status = "YELLOW"
        msg = "Conditions are mixed, but nothing alarming."

    if diversification < 0.2:
        msg += " Diversification is low, so your portfolio is concentrated."

    st.subheader("Overall Status")
    st.write(f"**Your portfolio today:** {status}")
    st.write(msg)

    # ---- Most Important Thing ----
    st.subheader("Most Important Thing")
    if status == "GREEN":
        st.write("No major action needed today.")
    elif status == "YELLOW":
        st.write("Review positions, but avoid quick decisions.")
    else:
        st.write("Focus on risk control and avoid large changes.")

    # ---- Top Suggestion ----
    st.subheader("Top Suggestion")
    if actions:
        sorted_actions = sorted(actions, key=lambda a: a["weight"], reverse=True)
        a = sorted_actions[0]
        st.write(f"For **{a['ticker']}**: {a['action']}")
    else:
        st.write("No specific action suggested today.")

    # ---- Opportunities ----
    st.subheader("Top Opportunities")
    if not high.empty:
        st.write("High conviction:")
        for _, row in high.head(2).iterrows():
            st.write(f"- **{row['ticker']}** — {row['notes']}")
    elif not medium.empty:
        st.write("Medium conviction:")
        for _, row in medium.head(2).iterrows():
            st.write(f"- **{row['ticker']}** — {row['notes']}")
    else:
        st.write("No clear opportunities today.")

    # ---- Risks ----
    st.subheader("Key Risks")
    risks = []
    for a in actions:
        if a["weight"] > 0.40:
            risks.append(f"{a['ticker']}: large share of portfolio")
        if a["asset_type"] == "crypto" and a["volatility"] > 0.40:
            risks.append(f"{a['ticker']}: crypto volatility is high")

    if risks:
        for r in risks:
            st.write(f"- {r}")
    else:
        st.write("No significant risks today beyond normal market movement.")

    st.write("")
    st.caption("This simplified view is informational only. All decisions should follow Tao’s judgment and comfort level.")

# ===================================================
# WATCHLIST PAGE (Full ThinkOrSwim-Style Watchlist)
# ===================================================

import yfinance as yf
from datetime import datetime, date

WATCHLIST_PATH = "watchlist.csv"
ASSET_TYPES = ["equity", "crypto", "index", "other"]
CRYPTO_PRESETS = ["BTC-USD", "ETH-USD", "SOL-USD", "DOGE-USD", "XRP-USD", "ADA-USD", "LTC-USD"]


def wl_normalize_asset_type(value: object) -> str:
    if not isinstance(value, str):
        return "other"
    v = str(value).strip().lower()
    if v in ("equity", "stock", "etf", "shares"):
        return "equity"
    if v in ("crypto", "cryptocurrency"):
        return "crypto"
    if v in ("index",):
        return "index"
    return "other"


def wl_auto_correct_crypto(ticker: str) -> str:
    t = ticker.upper().strip()
    if "-" in t:
        return t
    if len(t) in (2, 3, 4):
        return f"{t}-USD"
    return t


def wl_validate_crypto(ticker: str) -> bool:
    if "-" not in ticker:
        return False
    base, quote = ticker.split("-", 1)
    return base.isalpha() and quote in ("USD", "USDT", "EUR")


def wl_ensure_exists():
    try:
        pd.read_csv(WATCHLIST_PATH)
    except FileNotFoundError:
        df = pd.DataFrame(columns=["ticker", "added_at", "price_at_add", "asset_type", "notes"])
        df.to_csv(WATCHLIST_PATH, index=False)


def wl_load() -> pd.DataFrame:
    wl_ensure_exists()
    df = pd.read_csv(WATCHLIST_PATH)
    if df.empty:
        return df
    df.columns = [str(c).strip().lower() for c in df.columns]
    if "notes" not in df.columns:
        df["notes"] = ""
    if "asset_type" not in df.columns:
        df["asset_type"] = "equity"
    df["asset_type"] = df["asset_type"].apply(wl_normalize_asset_type)
    return df


def wl_save(df: pd.DataFrame):
    df.to_csv(WATCHLIST_PATH, index=False)


def wl_compute_rsi(series: pd.Series, period: int = 14) -> float | None:
    if series is None or len(series) < period + 1:
        return None
    delta = series.diff()
    gain = delta.where(delta > 0, 0).rolling(period).mean()
    loss = -delta.where(delta < 0, 0).rolling(period).mean()
    if loss.iloc[-1] == 0:
        return 100.0
    rs = gain.iloc[-1] / loss.iloc[-1]
    return float(100 - (100 / (1 + rs)))


@st.cache_data(ttl=60, show_spinner=False)
def wl_fetch_live(ticker: str):
    try:
        t = yf.Ticker(ticker)
        hist = t.history(period="2d")
        if hist.empty:
            return None

        last_row = hist.iloc[-1]
        last_price = float(last_row["Close"])
        open_price = float(last_row["Open"])
        high_price = float(last_row["High"])
        low_price = float(last_row["Low"])
        volume = int(last_row.get("Volume", 0))

        if len(hist) >= 2:
            prev_close = float(hist.iloc[-2]["Close"])
        else:
            prev_close = last_price

        net_change = last_price - prev_close
        net_change_pct = (last_price / prev_close - 1) * 100 if prev_close else 0

        # 52-week values + RSI
        hist_1y = t.history(period="1y")
        if not hist_1y.empty:
            fifty_two_high = float(hist_1y["High"].max())
            fifty_two_low = float(hist_1y["Low"].min())
            rsi_val = wl_compute_rsi(hist_1y["Close"], 14)
        else:
            fifty_two_high = None
            fifty_two_low = None
            rsi_val = None

        return {
            "last": last_price,
            "open": open_price,
            "high": high_price,
            "low": low_price,
            "volume": volume,
            "net_change": net_change,
            "net_change_pct": net_change_pct,
            "52w_high": fifty_two_high,
            "52w_low": fifty_two_low,
            "rsi": rsi_val,
        }
    except Exception:
        return None


def render_watchlist():
    st.title("📈 Watchlist")
    df = wl_load()

    tab_add, tab_remove, tab_view = st.tabs(
        ["➕ Add to Watchlist", "🗑 Remove from Watchlist", "📋 View Watchlist"]
    )

    # ---------------- ADD ----------------
    with tab_add:
        st.subheader("Add Ticker")

        asset_type = st.selectbox("Asset type", ASSET_TYPES, key="wl_type")

        if asset_type == "crypto":
            new_ticker = st.text_input("Ticker", "").upper().strip()
            st.info("Crypto auto-correct active: BTC → BTC-USD, ETH → ETH-USD")
            preset = st.selectbox("Crypto presets", ["(none)"] + CRYPTO_PRESETS, key="wl_crypto_preset")
            if preset != "(none)":
                new_ticker = preset
        else:
            new_ticker = st.text_input("Ticker", "").upper().strip()

        notes = st.text_area("Notes (optional)", key="wl_notes")

        if st.button("Add to Watchlist"):
            if not new_ticker:
                st.error("Ticker cannot be empty.")
                st.stop()

            # Crypto auto-correct + validation
            if asset_type == "crypto":
                corrected = wl_auto_correct_crypto(new_ticker)
                if corrected != new_ticker:
                    st.info(f"Using corrected crypto ticker: {corrected}")
                new_ticker = corrected

                if not wl_validate_crypto(new_ticker):
                    st.error("Invalid crypto ticker. Must be like BTC-USD or ETH-USD.")
                    st.stop()

            metrics = wl_fetch_live(new_ticker)
            if metrics is None:
                st.error("Could not fetch live data.")
            else:
                now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                price_at_add = metrics["last"]

                row = pd.DataFrame(
                    [{
                        "ticker": new_ticker,
                        "added_at": now_str,
                        "price_at_add": price_at_add,
                        "asset_type": asset_type,
                        "notes": notes,
                    }]
                )

                new_df = pd.concat([df, row], ignore_index=True)
                wl_save(new_df)
                st.success(f"Added {new_ticker} at {price_at_add:.2f}")
                st.rerun()

    # ---------------- REMOVE ----------------
    with tab_remove:
        st.subheader("Remove Ticker")

        if df.empty:
            st.info("Watchlist empty.")
        else:
            idx = st.selectbox(
                "Select entry to remove",
                df.index,
                format_func=lambda i: f"{df.loc[i,'ticker']} (added {df.loc[i,'added_at']})",
                key="wl_remove_idx"
            )
            if st.button("Remove"):
                symbol = df.loc[idx, "ticker"]
                new_df = df.drop(index=idx)
                wl_save(new_df)
                st.success(f"Removed {symbol}.")
                st.rerun()

    # ---------------- VIEW ----------------
    with tab_view:
        st.subheader("Watchlist Table")

        if df.empty:
            st.info("Nothing to display.")
        else:
            rows = []
            today = date.today()

            for _, r in df.iterrows():
                tkr = r["ticker"]
                added_at_str = r["added_at"]
                price_at_add = float(r["price_at_add"])
                notes = r.get("notes", "")

                try:
                    added_dt = datetime.strptime(added_at_str, "%Y-%m-%d %H:%M:%S")
                except:
                    added_dt = datetime.now()
                days_held = (today - added_dt.date()).days

                metrics = wl_fetch_live(tkr)
                if metrics is None:
                    continue

                last = metrics["last"]
                pl_dollar = last - price_at_add
                pl_percent = (last / price_at_add - 1) * 100 if price_at_add else 0

                rows.append({
                    "Ticker": tkr,
                    "Last": round(last, 2),
                    "Net Change": round(metrics["net_change"], 2),
                    "Net %": round(metrics["net_change_pct"], 2),
                    "Open": round(metrics["open"], 2),
                    "High": round(metrics["high"], 2),
                    "Low": round(metrics["low"], 2),
                    "Volume": metrics["volume"],
                    "52w High": metrics["52w_high"],
                    "52w Low": metrics["52w_low"],
                    "RSI": metrics["rsi"],
                    "Price at Add": round(price_at_add, 2),
                    "P/L $": round(pl_dollar, 2),
                    "P/L %": round(pl_percent, 2),
                    "Days": days_held,
                    "Notes": notes,
                })

            st.dataframe(pd.DataFrame(rows), use_container_width=True)

# ===================================================
# ROUTER — Sidebar Navigation
# ===================================================

page = st.sidebar.radio(
    "Page",
    [
        "📊 Dashboard",
        "🔍 Ticker Lookup",
        "📈 Watchlist",
        "⭐ Recommendations",
        "🧺 Portfolio Manager",
        "💡 Portfolio Insights",
        "🧠 Advisor View" 
    ]
)

if page == "📊 Dashboard":
    render_dashboard()

elif page == "🔍 Ticker Lookup":
    render_lookup()

elif page == "📈 Watchlist":
    render_watchlist()

elif page == "⭐ Recommendations":
    render_recommendations()

elif page == "🧺 Portfolio Manager":
    render_portfolio_manager()

elif page == "💡 Portfolio Insights":
    render_portfolio_insights()

elif page == "🧠 Advisor View":
    import advisor_view
    advisor_view.run()

