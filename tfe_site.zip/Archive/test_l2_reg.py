import pandas as pd
import numpy as np

from uf_core.layer0 import compute_sev_series
from uf_core.layer1 import segment_gates
from uf_core.layer2 import interpret_gates
from uf_core.config import KERNEL_THRESHOLDS


def main():
    prices = [100, 101, 102, 110, 111, 112, 113, 90, 91, 92, 93, 94]
    df = pd.DataFrame({"Close": prices})

    sev_list = compute_sev_series(df)
    gates = segment_gates(sev_list)
    interpretations = interpret_gates(sev_list, gates)

    print("Total gates:", len(gates))
    print("Total interpretations:", len(interpretations))
    print("Regime thresholds (S_LOW, S_HIGH, U_LOW, U_HIGH) = (1.0, 2.0, 0.3, 0.8)")
    print("U_max (IAS threshold) =", KERNEL_THRESHOLDS.U_max)

    for idx, interp in enumerate(interpretations, start=1):
        gate = interp.gate
        CV_k = np.array(interp.CV_k)
        w_k = interp.w_k
        S_k = interp.S_k
        U_k = interp.U_k
        IAS_k = interp.IAS_k
        regime = interp.regime

        print(f"\nGate {idx}:")
        print(f" Index range = [{gate.start_idx}, {gate.end_idx}]")
        print(f" w_k         = {w_k:.6f}")
        print(f" ||CV_k||    = {np.linalg.norm(CV_k):.6f}")
        print(f" S_k         = {S_k:.6f}")
        print(f" U_k         = {U_k:.6f}")
        print(f" IAS_k       = {IAS_k}")
        print(f" Regime      = {regime}")


if __name__ == "__main__":
    main()
