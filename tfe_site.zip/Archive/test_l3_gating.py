import pandas as pd
import numpy as np

from uf_core.layer0 import compute_sev_series
from uf_core.layer1 import segment_gates
from uf_core.layer2 import interpret_gates
from uf_core.layer3 import compute_resonance
from uf_core.config import KERNEL_THRESHOLDS


def main():
    prices = [100, 101, 102, 110, 111, 112, 113, 90, 91, 92, 93, 94]
    df = pd.DataFrame({"Close": prices})

    sev_list = compute_sev_series(df)
    gates = segment_gates(sev_list)
    interpretations = interpret_gates(sev_list, gates)
    resonance_results = compute_resonance(interpretations)

    print("Total gates:", len(gates))
    print("U_max =", KERNEL_THRESHOLDS.U_max)

    for idx, res in enumerate(resonance_results, start=1):
        interp = res.interpretation
        gate = interp.gate

        CV_k = np.array(interp.CV_k, dtype=float)
        w_k = interp.w_k
        S_k = interp.S_k
        U_k = interp.U_k
        IAS_k = interp.IAS_k
        regime = interp.regime

        R_k = res.R_k
        H_k = res.Hyst_k
        g_k = res.g_k
        URF_k = res.URF_k

        print(f"\nGate {idx}:")
        print(f" Index range = [{gate.start_idx}, {gate.end_idx}]")
        print(f" Regime      = {regime}")
        print(f" w_k         = {w_k:.6f}")
        print(f" ||CV_k||    = {np.linalg.norm(CV_k):.6f}")
        print(f" S_k         = {S_k:.6f}")
        print(f" U_k         = {U_k:.6f}")
        print(f" IAS_k       = {IAS_k}")
        print(f" R_k         = {R_k:.6f}")
        print(f" Hyst_k      = {H_k}")
        print(f" g_k         = {g_k}")
        print(f" URF_k       = {URF_k:.6f}  (should be R_k when g_k=1, else 0)")


if __name__ == "__main__":
    main()
