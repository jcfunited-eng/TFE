import streamlit as st
import pandas as pd
import yfinance as yf
from datetime import datetime, date

WATCHLIST_PATH = "watchlist.csv"

ASSET_TYPES = ["equity", "crypto", "index", "other"]

CRYPTO_PRESETS = [
    "BTC-USD",
    "ETH-USD",
    "SOL-USD",
    "DOGE-USD",
    "XRP-USD",
    "ADA-USD",
    "LTC-USD"
]


# ----------------- UTILITIES -----------------

def normalize_asset_type(value: object) -> str:
    if not isinstance(value, str):
        return "other"
    v = str(value).strip().lower()
    if v in ("equity", "stock", "etf", "shares"):
        return "equity"
    if v in ("crypto", "cryptocurrency"):
        return "crypto"
    if v in ("index",):
        return "index"
    return "other"


def auto_correct_crypto(ticker: str) -> str:
    """
    Implements Mommy's preferred behavior:
    If asset_type=crypto, smart-correct tickers:
    BTC -> BTC-USD
    eth -> ETH-USD
    sol -> SOL-USD
    """
    t = ticker.upper().strip()

    # already correct
    if "-" in t:
        return t

    # short codes assumed to be crypto
    if len(t) in (2, 3, 4):
        return f"{t}-USD"

    return t


def validate_crypto(ticker: str) -> bool:
    """
    Crypto tickers must be something like BTC-USD or ETH-USD.
    """
    if "-" not in ticker:
        return False
    base, quote = ticker.split("-", 1)
    if not base.isalpha():
        return False
    if quote not in ("USD", "USDT", "EUR"):
        return False
    return True


def ensure_watchlist_exists():
    try:
        pd.read_csv(WATCHLIST_PATH)
    except FileNotFoundError:
        df = pd.DataFrame(columns=["ticker", "added_at", "price_at_add", "asset_type", "notes"])
        df.to_csv(WATCHLIST_PATH, index=False)


def load_watchlist() -> pd.DataFrame:
    ensure_watchlist_exists()
    df = pd.read_csv(WATCHLIST_PATH)
    if df.empty:
        return df
    df.columns = [str(c).strip().lower() for c in df.columns]
    if "notes" not in df.columns:
        df["notes"] = ""
    if "asset_type" not in df.columns:
        df["asset_type"] = "equity"
    df["asset_type"] = df["asset_type"].apply(normalize_asset_type)
    return df


def save_watchlist(df: pd.DataFrame):
    df.to_csv(WATCHLIST_PATH, index=False)


def compute_rsi(series: pd.Series, period: int = 14) -> float | None:
    if series is None or len(series) < period + 1:
        return None
    delta = series.diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
    if loss.iloc[-1] == 0:
        return 100.0
    rs = gain.iloc[-1] / loss.iloc[-1]
    rsi = 100 - (100 / (1 + rs))
    return float(rsi)


@st.cache_data(ttl=60, show_spinner=False)
def fetch_live_metrics(ticker: str):
    try:
        t = yf.Ticker(ticker)
        hist = t.history(period="2d")
        if hist.empty:
            return None

        last_row = hist.iloc[-1]
        last_price = float(last_row["Close"])
        open_price = float(last_row["Open"])
        high_price = float(last_row["High"])
        low_price = float(last_row["Low"])
        volume = int(last_row.get("Volume", 0))

        if len(hist) >= 2:
            prev_close = float(hist.iloc[-2]["Close"])
        else:
            prev_close = last_price

        net_change = last_price - prev_close
        net_change_pct = (last_price / prev_close - 1) * 100 if prev_close != 0 else 0.0

        hist_1y = t.history(period="1y")
        if not hist_1y.empty:
            fifty_two_high = float(hist_1y["High"].max())
            fifty_two_low = float(hist_1y["Low"].min())
            rsi_val = compute_rsi(hist_1y["Close"], period=14)
        else:
            fifty_two_high = None
            fifty_two_low = None
            rsi_val = None

        return {
            "last": last_price,
            "open": open_price,
            "high": high_price,
            "low": low_price,
            "volume": volume,
            "net_change": net_change,
            "net_change_pct": net_change_pct,
            "52w_high": fifty_two_high,
            "52w_low": fifty_two_low,
            "rsi": rsi_val,
        }
    except Exception:
        return None


# ----------------- MAIN APP -----------------

def main():
    st.set_page_config(page_title="Watchlist Test", layout="wide")
    st.title("📈 Watchlist — Test App")

    df = load_watchlist()

    tab_add, tab_remove, tab_view = st.tabs(
        ["➕ Add to Watchlist", "🗑 Remove from Watchlist", "📋 View Watchlist"]
    )

    # ------------------------------------------------
    # ADD TO WATCHLIST
    # ------------------------------------------------
    with tab_add:
        st.subheader("Add Ticker to Watchlist")

        asset_type = st.selectbox("Asset type", ASSET_TYPES, index=0, key="wl_type")

        # If crypto, use helpful preset dropdown
        if asset_type == "crypto":
            new_ticker = st.text_input(
                "Ticker (crypto symbols auto-corrected)",
                value="",
                key="wl_ticker",
                placeholder="BTC-USD",
            )
            st.markdown(
                "**Tip:** Try entering 'BTC' or 'ETH' — we will auto-correct to BTC-USD or ETH-USD."
            )
            preset = st.selectbox(
                "Common Crypto Symbols (optional)",
                ["(none)"] + CRYPTO_PRESETS,
                index=0,
                key="wl_crypto_presets",
            )
            if preset != "(none)":
                new_ticker = preset

        else:
            new_ticker = st.text_input("Ticker (e.g., AAPL, VOO, ^GSPC)", "").upper().strip()
            st.markdown("Equity/index tickers are auto-normalized but not modified.")

        new_notes = st.text_area("Notes (optional)", key="wl_notes")

        if st.button("Add to Watchlist"):
            if not new_ticker:
                st.error("Ticker cannot be empty.")
                st.stop()

            # Normalize
            new_ticker = new_ticker.upper().strip()

            # Crypto-specific auto-correction
            if asset_type == "crypto":
                corrected = auto_correct_crypto(new_ticker)
                if corrected != new_ticker:
                    st.info(f"Crypto ticker corrected to **{corrected}**.")
                new_ticker = corrected

                # Validate
                if not validate_crypto(new_ticker):
                    st.error(
                        "Invalid crypto symbol. Format must be BTC-USD, ETH-USD, etc."
                    )
                    st.stop()

            # Safety: warn if mismatch
            if asset_type != "crypto" and "-" in new_ticker:
                st.warning(
                    f"Symbol **{new_ticker}** looks like a crypto symbol. "
                    f"Change asset type to crypto?"
                )

            metrics = fetch_live_metrics(new_ticker)
            if metrics is None:
                st.error("Could not fetch live data for this ticker.")
            else:
                now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                price_at_add = metrics["last"]

                new_row = pd.DataFrame(
                    [{
                        "ticker": new_ticker,
                        "added_at": now_str,
                        "price_at_add": price_at_add,
                        "asset_type": asset_type,
                        "notes": new_notes,
                    }]
                )

                df_new = pd.concat([df, new_row], ignore_index=True)
                save_watchlist(df_new)
                st.success(f"Added {new_ticker} at snapshot price {price_at_add:.2f}.")
                st.rerun()

    # ------------------------------------------------
    # REMOVE FROM WATCHLIST
    # ------------------------------------------------
    with tab_remove:
        st.subheader("Remove from Watchlist")

        if df.empty:
            st.info("Watchlist is empty.")
        else:
            idx = st.selectbox(
                "Select entry to remove",
                df.index,
                format_func=lambda i: f"{df.loc[i, 'ticker']} (added {df.loc[i, 'added_at']})",
            )
            if st.button("Remove"):
                tkr = df.loc[idx, "ticker"]
                df_new = df.drop(index=idx)
                save_watchlist(df_new)
                st.success(f"Removed {tkr} from watchlist.")
                st.rerun()

    # ------------------------------------------------
    # VIEW WATCHLIST
    # ------------------------------------------------
    with tab_view:
        st.subheader("Watchlist Overview")

        if df.empty:
            st.info("Watchlist is empty.")
        else:
            rows = []
            today = date.today()

            for _, row in df.iterrows():
                ticker = row["ticker"]
                added_at_str = row["added_at"]
                price_at_add = float(row["price_at_add"])
                notes = row.get("notes", "")

                # parse added_at
                try:
                    added_dt = datetime.strptime(added_at_str, "%Y-%m-%d %H:%M:%S")
                except Exception:
                    added_dt = datetime.now()
                days_tracked = (today - added_dt.date()).days

                metrics = fetch_live_metrics(ticker)
                if metrics is None:
                    continue

                last = metrics["last"]
                net_change = metrics["net_change"]
                net_change_pct = metrics["net_change_pct"]
                open_price = metrics["open"]
                high_price = metrics["high"]
                low_price = metrics["low"]
                volume = metrics["volume"]
                fifty_two_high = metrics["52w_high"]
                fifty_two_low = metrics["52w_low"]
                rsi_val = metrics["rsi"]

                pl_dollar = last - price_at_add
                pl_percent = (last / price_at_add - 1) * 100 if price_at_add != 0 else 0.0

                rows.append({
                    "Ticker": ticker,
                    "Last": round(last, 2),
                    "Net Change": round(net_change, 2),
                    "Net %": round(net_change_pct, 2),
                    "Open": round(open_price, 2),
                    "High": round(high_price, 2),
                    "Low": round(low_price, 2),
                    "Volume": volume,
                    "52w High": round(fifty_two_high, 2) if fifty_two_high else None,
                    "52w Low": round(fifty_two_low, 2) if fifty_two_low else None,
                    "RSI(14)": round(rsi_val, 1) if rsi_val else None,
                    "Price @ Add": round(price_at_add, 2),
                    "P/L $": round(pl_dollar, 2),
                    "P/L %": round(pl_percent, 2),
                    "Days": days_tracked,
                    "Notes": notes,
                })

            wl_table = pd.DataFrame(rows)
            st.dataframe(wl_table, use_container_width=True)


if __name__ == "__main__":
    main()
