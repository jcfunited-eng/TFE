import pandas as pd
import numpy as np

from uf_core.layer0 import compute_sev_series
from uf_core.layer1 import segment_gates
from uf_core.layer2 import interpret_gates
from uf_core.layer3 import compute_resonance
from uf_core.layer4 import compute_directional_signal
from uf_core.config import KERNEL_THRESHOLDS


def main():
    prices = [100, 101, 102, 110, 111, 112, 113, 90, 91, 92, 93, 94]
    df = pd.DataFrame({"Close": prices})

    sev_list = compute_sev_series(df)
    gates = segment_gates(sev_list)
    interpretations = interpret_gates(sev_list, gates)
    resonance_results = compute_resonance(interpretations)

    # L4 directional signal
    decision_states = compute_directional_signal(resonance_results)

    print("Total gates:", len(decision_states))
    print("Directional threshold epsilon_D =", KERNEL_THRESHOLDS.epsilon_D)

    prev_R = None

    for idx, ds in enumerate(decision_states, start=1):
        interp = ds.resonance_result.interpretation
        res = ds.resonance_result

        gate = interp.gate
        R_k = res.R_k
        delta_R = ds.delta_R
        D_k = ds.D_k
        H_k = res.Hyst_k
        U_k = interp.U_k
        IAS_k = interp.IAS_k

        print(f"\nGate {idx}:")
        print(f" Index range = [{gate.start_idx}, {gate.end_idx}]")
        print(f" R_k         = {R_k:.6f}")
        print(f" ΔR(k)       = {delta_R:.6f}")
        print(f" D_k         = {D_k}   (+1,0,-1)")
        print(f" U_k         = {U_k:.6f}")
        print(f" IAS_k       = {IAS_k}")
        print(f" Hyst_k      = {H_k}")

        if prev_R is None:
            expected = "N/A (first gate)"
        else:
            if delta_R > KERNEL_THRESHOLDS.epsilon_D:
                expected = "+1"
            elif delta_R < -KERNEL_THRESHOLDS.epsilon_D:
                expected = "-1"
            else:
                expected = "0"

        print(f" Expected D_k = {expected}")

        prev_R = R_k


if __name__ == "__main__":
    main()
