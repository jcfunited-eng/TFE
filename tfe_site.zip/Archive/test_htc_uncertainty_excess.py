"""
Test for Hardening Trigger Condition HTC-6 (Uncertainty Excess).

We supply:
    uncertainty_rate = 0.5  (> threshold 0.20)

Expected:
    flags.uncertainty_excess == True
    raw_metrics['uncertainty_rate'] == 0.5
    notes contains 'Uncertainty rate above threshold (0.2)'

All other hardening flags should remain False.
"""

import os
import sys

# Ensure project root is on path
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = current_dir
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from uf_core.hardening import (
    evaluate_htc,
    KernelStatusFlags,
    HardeningEvaluationResult,
)


def main():
    stability_scores = {
        "uncertainty_rate": 0.5
    }

    result = evaluate_htc(stability_scores=stability_scores)

    print("HTC-6 Uncertainty Excess Test Result:")
    print(result)

    print("\nFlags:", result.flags)
    print("Raw metrics:", result.raw_metrics)
    print("Notes:", result.notes)

    print("\nExplicit Checks:")
    print("Uncertainty Excess Flag (should be True):", result.flags.uncertainty_excess)
    print("Stored Uncertainty Rate:", result.raw_metrics.get("uncertainty_rate"))
    print(
        "Has uncertainty excess note:",
        any("Uncertainty rate above threshold" in note for note in result.notes),
    )

    # Make sure no other flags fire
    print("\nDSF Collapse Flag (should be False):", result.flags.dsf_collapse)
    print("Directional Collapse Flag (should be False):", result.flags.directional_collapse)
    print("Hysteresis Overload Flag (should be False):", result.flags.hysteresis_overload)
    print("Breathing Instability Flag (should be False):", result.flags.breathing_instability)
    print("Composite S_low Flag (should be False):", result.flags.composite_S_low)
    print("Composite R_low Flag (should be False):", result.flags.composite_R_low)
    print("Gate Drift Excess Flag (should be False):", result.flags.gate_drift_excess)


if __name__ == "__main__":
    main()
