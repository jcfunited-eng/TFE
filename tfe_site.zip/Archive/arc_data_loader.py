import os
from typing import Dict, Iterable

import pandas as pd
import requests
import yfinance as yf
from dotenv import load_dotenv

# Load environment variables from .env (Alpaca keys)
load_dotenv()

ALPACA_KEY = os.getenv("ALPACA_API_KEY")
ALPACA_SECRET = os.getenv("ALPACA_API_SECRET")
ALPACA_URL = os.getenv("ALPACA_API_URL", "https://data.alpaca.markets/v2")


# ---------- PRICE HELPERS ----------

def _fetch_alpaca_price(ticker: str) -> float:
    """
    Fetch latest stock/ETF price from Alpaca.
    Used for non-crypto tickers.
    """
    url = f"{ALPACA_URL}/stocks/{ticker}/quotes/latest"
    headers = {
        "APCA-API-KEY-ID": ALPACA_KEY,
        "APCA-API-SECRET-KEY": ALPACA_SECRET,
    }

    r = requests.get(url, headers=headers, timeout=10)
    if r.status_code != 200:
        raise ValueError(f"Alpaca error for {ticker}: {r.text}")

    data = r.json()
    quote = data.get("quote")
    if not quote:
        raise ValueError(f"Alpaca returned no quote for {ticker}: {data}")

    # Use ask price if available, otherwise last price-ish
    price = quote.get("ap") or quote.get("bp") or quote.get("lp")
    if price is None:
        raise ValueError(f"Alpaca quote missing price for {ticker}: {quote}")

    return float(price)


def _fetch_yahoo_price(ticker: str) -> float:
    """
    Fetch latest price from Yahoo Finance (used for crypto and as fallback).
    """
    t = yf.Ticker(ticker)
    hist = t.history(period="1d")
    if hist.empty:
        raise ValueError(f"No Yahoo price data for {ticker}")
    return float(hist["Close"].iloc[-1])


def latest_prices(tickers: Iterable[str]) -> Dict[str, float]:
    """
    Get latest prices for a list of tickers.

    - Crypto (e.g. BTC-USD, ETH-USD) -> Yahoo Finance only
    - Stocks/ETFs -> Alpaca first, fallback to Yahoo if needed
    """
    result: Dict[str, float] = {}

    for ticker in tickers:
        try:
            if ticker.endswith("-USD"):
                # Crypto: use Yahoo
                result[ticker] = _fetch_yahoo_price(ticker)
            else:
                # Stock/ETF: try Alpaca first, then Yahoo as backup
                try:
                    result[ticker] = _fetch_alpaca_price(ticker)
                except Exception:
                    # Fallback if Alpaca fails for any reason
                    result[ticker] = _fetch_yahoo_price(ticker)
        except Exception as e:
            # If everything fails, just skip that ticker
            print(f"[WARN] Could not fetch latest price for {ticker}: {e}")

    return result


# ---------- HISTORY HELPERS ----------

def _fetch_yahoo_history(ticker: str, period: str = "6mo") -> pd.DataFrame:
    """
    Fetch historical OHLCV data for *any* ticker from Yahoo Finance.
    Used for both stocks/ETFs and crypto.
    """
    t = yf.Ticker(ticker)
    hist = t.history(period=period)

    if hist.empty:
        raise ValueError(f"No historical data from Yahoo for {ticker}")

    # Normalize column names to match rest of engine
    hist = hist.rename(
        columns={
            "Open": "open",
            "High": "high",
            "Low": "low",
            "Close": "close",
            "Volume": "volume",
        }
    )
    return hist[["open", "high", "low", "close", "volume"]]


def load_price_history(ticker: str) -> pd.DataFrame:
    """
    Unified function used by the engine/UI to get historical data.
    For simplicity and reliability, we use Yahoo Finance for everything.
    """
    return _fetch_yahoo_history(ticker, period="6mo")
