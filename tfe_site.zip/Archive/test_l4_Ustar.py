import pandas as pd

from uf_core.layer0 import compute_sev_series
from uf_core.layer1 import segment_gates
from uf_core.layer2 import interpret_gates
from uf_core.layer3 import compute_resonance
from uf_core.layer4 import compute_directional_signal


def main():
    prices = [100, 101, 102, 110, 111, 112, 113, 90, 91, 92, 93, 94]
    df = pd.DataFrame({"Close": prices})

    sev_list = compute_sev_series(df)
    gates = segment_gates(sev_list)
    interpretations = interpret_gates(sev_list, gates)
    resonance_results = compute_resonance(interpretations)
    decision_states = compute_directional_signal(resonance_results)

    print("Total gates:", len(decision_states))
    print("U*_k = bounded(1 - U_k) in [0, 1]\n")

    for idx, ds in enumerate(decision_states, start=1):
        res = ds.resonance_result
        interp = res.interpretation

        U_k = float(interp.U_k)
        U_star_k = ds.U_star_k

        # Compute theoretical U* for verification
        raw = 1.0 - U_k
        expected = max(0.0, min(1.0, raw))

        print(f"Gate {idx}:")
        print(f" U_k        = {U_k:.6f}")
        print(f" U*_k       = {U_star_k:.6f}")
        print(f" Expected   = {expected:.6f}")
        print(f" In [0,1]?  = {0.0 <= U_star_k <= 1.0}\n")


if __name__ == "__main__":
    main()
