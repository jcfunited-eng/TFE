"""
Test for Hardening Action HA-3 (Gate Freeze, Absolute Freeze Mode).

This test validates:

1) If gate_drift_excess is False:
    - apply_gate_freeze returns current_gates unchanged.

2) If gate_drift_excess is True and frozen_gates is None:
    - apply_gate_freeze returns a snapshot of current_gates.

3) If gate_drift_excess is True and frozen_gates is provided:
    - apply_gate_freeze returns frozen_gates unchanged, regardless of current_gates.
"""

import os
import sys

# Ensure project root is importable
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = current_dir
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from uf_core.hardening import KernelStatusFlags, HardeningEvaluationResult
from uf_core.layer1 import Gate
from uf_core.hardening_actions import apply_gate_freeze


def make_gates_a():
    """Simple gate set A."""
    return [
        Gate(start_idx=0, end_idx=10),
        Gate(start_idx=11, end_idx=20),
    ]


def make_gates_b():
    """Simple gate set B, distinct from A."""
    return [
        Gate(start_idx=0, end_idx=5),
        Gate(start_idx=6, end_idx=15),
    ]


def main():
    print("=== HA-3 Gate Freeze Test ===\n")

    # ----------------------------------------------------------
    # Case 1: No gate drift excess → pass-through behavior
    # ----------------------------------------------------------

    gates_a = make_gates_a()

    flags1 = KernelStatusFlags(gate_drift_excess=False)
    htc_result1 = HardeningEvaluationResult(flags=flags1, raw_metrics={}, notes=[])

    out1 = apply_gate_freeze(htc_result1, current_gates=gates_a, frozen_gates=None)

    print("Case 1 — No gate drift excess (pass-through):")
    for g in out1:
        print(g)

    # ----------------------------------------------------------
    # Case 2: Gate drift excess with no frozen snapshot
    # ----------------------------------------------------------

    flags2 = KernelStatusFlags(gate_drift_excess=True)
    htc_result2 = HardeningEvaluationResult(flags=flags2, raw_metrics={}, notes=[])

    out2 = apply_gate_freeze(htc_result2, current_gates=gates_a, frozen_gates=None)

    print("\nCase 2 — Gate drift excess, no frozen_gates (snapshot of current_gates):")
    for g in out2:
        print(g)

    # ----------------------------------------------------------
    # Case 3: Gate drift excess with existing frozen snapshot
    # ----------------------------------------------------------

    gates_b = make_gates_b()

    out3 = apply_gate_freeze(htc_result2, current_gates=gates_b, frozen_gates=out2)

    print("\nCase 3 — Gate drift excess, frozen_gates provided (must return frozen_gates):")
    for g in out3:
        print(g)


if __name__ == "__main__":
    main()
