"""
rebuild_uf_snapshot.py

Unified rebuild tool for UF snapshot generation.

This version:
- Includes STOCKS, ETFs, INDEXES, CRYPTO (via Massive universe files)
- Uses only the Massive data acquisition methods supported by your plan
- Uses the existing UF-Core structural pipeline exactly as-is
- Produces:
    • uf_structural_cache.json
    • uf_snapshot.json
    • uf_snapshot_old_backup.json

No TA logic.
No predictive behavior.
Pure structural UF-Spec v1.4.0 processing.

Run:
    python rebuild_uf_snapshot.py
"""

from __future__ import annotations

import json
import datetime
import os
import sys

from typing import List, Dict, Any

# -------------------------------------------------------------------
# Universe providers (now including index + crypto)
# -------------------------------------------------------------------
from massive_universe_cache import get_stock_tickers_from_universe
from massive_universe_cache_etf import get_etf_tickers_from_universe
from massive_universe_index import get_index_tickers_from_universe
from massive_universe_crypto import get_crypto_tickers_from_universe

# -------------------------------------------------------------------
# Market data access (Massive-only aggregates + Alpaca fallback)
# -------------------------------------------------------------------
from unified_market_data_service import get_unified_market_data

# -------------------------------------------------------------------
# UF-Core engine
# -------------------------------------------------------------------
from uf_core.uf_structural_engine import compute_structural_state

STRUCTURAL_CACHE_PATH = "uf_structural_cache.json"
SNAPSHOT_PATH = "uf_snapshot.json"
SNAPSHOT_BACKUP_PATH = "uf_snapshot_old_backup.json"


def _load_existing_structural_cache() -> Dict[str, Any]:
    if not os.path.exists(STRUCTURAL_CACHE_PATH):
        return {}
    try:
        with open(STRUCTURAL_CACHE_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _save_structural_cache(cache: Dict[str, Any]) -> None:
    try:
        with open(STRUCTURAL_CACHE_PATH, "w", encoding="utf-8") as f:
            json.dump(cache, f, indent=2)
    except Exception:
        pass


def _backup_old_snapshot() -> None:
    if os.path.exists(SNAPSHOT_PATH):
        try:
            os.replace(SNAPSHOT_PATH, SNAPSHOT_BACKUP_PATH)
        except Exception:
            pass


def _save_snapshot(rows: List[Dict[str, Any]]) -> None:
    try:
        with open(SNAPSHOT_PATH, "w", encoding="utf-8") as f:
            json.dump(rows, f, indent=2)
    except Exception:
        pass


def _now_utc_date() -> datetime.date:
    return datetime.datetime.utcnow().date()


def rebuild_snapshot() -> None:
    print("[UF-SNAPSHOT] Starting unified rebuild...")

    # -------------------------------------------------------------
    # 1. Build the combined universe
    # -------------------------------------------------------------
    stocks = get_stock_tickers_from_universe(force_refresh=False)
    etfs = get_etf_tickers_from_universe(force_refresh=False)
    indexes = get_index_tickers_from_universe(force_refresh=False)
    crypto = get_crypto_tickers_from_universe(force_refresh=False)

    universe = list(dict.fromkeys(stocks + etfs + indexes + crypto))

    print(f"[UF-SNAPSHOT] Universe size: {len(universe)} symbols")

    # -------------------------------------------------------------
    # 2. Load existing structural cache (may supply partial reuse)
    # -------------------------------------------------------------
    structural_cache: Dict[str, Any] = _load_existing_structural_cache()

    # -------------------------------------------------------------
    # 3. Market data client (Massive aggregates + Alpaca fallback)
    # -------------------------------------------------------------
    mds = get_unified_market_data()
    today = _now_utc_date()

    snapshot_rows: List[Dict[str, Any]] = []

    # -------------------------------------------------------------
    # 4. Per-symbol structural evaluation (UF L0–L4)
    # -------------------------------------------------------------
    for i, symbol in enumerate(universe):
        if (i % 200) == 0:
            print(f"[UF-SNAPSHOT] Processing {i}/{len(universe)}...")

        # UF requires historical bars
        # Request 5 years max because your plan provides this
        start = today - datetime.timedelta(days=5 * 365)

        try:
            hist = mds.get_history(
                request=dict(
                    symbol=symbol,
                    start=start,
                    end=today,
                )
            )
            bars = hist.bars
        except Exception:
            bars = []

        # Skip symbols with insufficient bars (< 30)
        if len(bars) < 30:
            print(f"[UF-SNAPSHOT] too few bars for {symbol}: {len(bars)}")
            continue

        # Compute UF structural state (L0–L4)
        try:
            state = compute_structural_state(symbol=symbol, bars=bars)
        except Exception as exc:
            print(f"[UF-SNAPSHOT] structural failure for {symbol}: {exc}")
            continue

        # Save to structural cache
        structural_cache[symbol] = state

        # Prepare flat snapshot row
        snapshot_rows.append(
            {
                "ticker": symbol,
                "asset_type": _infer_asset_type(symbol, etfs, indexes, crypto),
                "price": state.get("last_close"),
                "regime": state.get("regime"),
                "S_UF": state.get("S_UF"),
