import streamlit as st
import pandas as pd

# Path to your portfolio file
PORTFOLIO_PATH = "portfolio.csv"

# Allowed asset type labels
ASSET_TYPES = ["equity", "crypto", "index", "other"]


def normalize_asset_type(value: object) -> str:
    """Map various labels into a small set of asset types."""
    if not isinstance(value, str):
        return "other"
    v = value.strip().lower()
    if v in ("equity", "stock", "etf", "shares"):
        return "equity"
    if v in ("crypto", "cryptocurrency"):
        return "crypto"
    if v in ("index",):
        return "index"
    return "other"


def load_portfolio() -> pd.DataFrame:
    """Load CSV file, supporting comma or tab delimiters."""
    df = pd.read_csv(PORTFOLIO_PATH, sep=None, engine="python")
    df.columns = [str(c).strip().lower() for c in df.columns]

    required = {"ticker", "quantity", "cost_basis"}
    if not required.issubset(df.columns):
        raise ValueError(f"portfolio.csv must contain: {required}")

    if "asset_type" not in df.columns:
        df["asset_type"] = "equity"

    df["asset_type"] = df["asset_type"].apply(normalize_asset_type)
    df = df[["ticker", "quantity", "cost_basis", "asset_type"]]
    return df


def save_portfolio(df: pd.DataFrame) -> None:
    df.to_csv(PORTFOLIO_PATH, index=False)


def main():
    st.set_page_config(page_title="Portfolio Manager", layout="wide")
    st.title("🧺 Portfolio Manager (Standalone Clean Version)")

    try:
        df = load_portfolio()
    except Exception as e:
        st.error(f"Could not load portfolio.csv: {e}")
        return

    tab_add, tab_remove, tab_update, tab_view = st.tabs(
        ["➕ Add Asset", "🗑 Remove Asset", "✏️ Update Asset", "📋 View Raw Data"]
    )

    # ------------------------------------------------------------------
    with tab_add:
        st.subheader("Add Asset")
        ticker = st.text_input("Ticker").upper().strip()
        qty = st.number_input("Quantity", min_value=0.0, format="%.4f")
        cost = st.number_input("Cost basis ($ per unit)", min_value=0.0, format="%.4f")
        atype = st.selectbox("Asset type", ASSET_TYPES)

        if st.button("Add to portfolio"):
            if not ticker:
                st.error("Ticker cannot be empty.")
            else:
                new_row = pd.DataFrame([{
                    "ticker": ticker,
                    "quantity": qty,
                    "cost_basis": cost,
                    "asset_type": atype,
                }])
                new_df = pd.concat([df, new_row], ignore_index=True)
                save_portfolio(new_df)
                st.success(f"Added {ticker}.")
                st.rerun()

    # ------------------------------------------------------------------
    with tab_remove:
        st.subheader("Remove Asset")
        if df.empty:
            st.info("Portfolio is empty.")
        else:
            idx = st.selectbox(
                "Select asset to remove",
                df.index,
                format_func=lambda i: f"{df.loc[i,'ticker']} (qty={df.loc[i,'quantity']})"
            )
            if st.button("Remove"):
                new_df = df.drop(index=idx)
                save_portfolio(new_df)
                st.success(f"Removed {df.loc[idx, 'ticker']}.")
                st.rerun()

    # ------------------------------------------------------------------
    with tab_update:
        st.subheader("Update Asset")

        if df.empty:
            st.info("Portfolio is empty.")
        else:
            idx = st.selectbox(
                "Select asset to update",
                df.index,
                format_func=lambda i: f"{df.loc[i,'ticker']} (qty={df.loc[i,'quantity']})",
                key="update_selectbox"
            )

            # Row to update
            row = df.loc[idx]

            # DYNAMIC KEYS = FORCE STREAMLIT TO REFRESH INPUTS
            qty = st.number_input(
                "Quantity",
                min_value=0.0,
                value=float(row["quantity"]),
                format="%.4f",
                key=f"qty_input_{idx}"
            )
            cost = st.number_input(
                "Cost basis ($ per unit)",
                min_value=0.0,
                value=float(row["cost_basis"]),
                format="%.4f",
                key=f"cost_input_{idx}"
            )
            atype = st.selectbox(
                "Asset type",
                ASSET_TYPES,
                index=ASSET_TYPES.index(normalize_asset_type(row["asset_type"])),
                key=f"type_input_{idx}"
            )

            if st.button("Save changes", key=f"save_btn_{idx}"):
                df2 = df.copy()
                df2.at[idx, "quantity"] = qty
                df2.at[idx, "cost_basis"] = cost
                df2.at[idx, "asset_type"] = atype
                save_portfolio(df2)
                st.success(f"Updated {row['ticker']}.")
                st.rerun()

    # ------------------------------------------------------------------
    with tab_view:
        st.subheader("Current portfolio data (raw)")
        st.dataframe(df, use_container_width=True)


if __name__ == "__main__":
    main()
