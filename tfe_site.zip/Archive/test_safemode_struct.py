"""
Structural validation for safemode.py.

This test verifies:
- SafeModeState dataclass instantiation
- init_safemode_state() returns a neutral SafeModeState
- Field types are correct
"""

import os
import sys

# Ensure project root is importable
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = current_dir
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from uf_core.safemode import SafeModeState, init_safemode_state


def main():
    print("=== SafeMode Structure Test ===\n")

    # Direct construction
    state_direct = SafeModeState()
    print("Direct SafeModeState():")
    print(state_direct)

    # Using initializer function
    state_init = init_safemode_state()
    print("\ninit_safemode_state():")
    print(state_init)

    print("\nExplicit Type Checks:")
    print("safe_mode is bool:", isinstance(state_init.safe_mode, bool))
    print("entry_step is None or int:", isinstance(state_init.entry_step, (int, type(None))))
    print("entry_reasons is list:", isinstance(state_init.entry_reasons, list))
    print("frozen_gates is None or list:", state_init.frozen_gates is None or isinstance(state_init.frozen_gates, list))
    print("latest_metrics is dict:", isinstance(state_init.latest_metrics, dict))


if __name__ == "__main__":
    main()
