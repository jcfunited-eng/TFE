"""
Structural validation of evaluate_htc().

This test ensures:
- evaluate_htc() returns a HardeningEvaluationResult
- Flags are a KernelStatusFlags instance
- raw_metrics is an empty dict
- notes is an empty list
"""

import os
import sys

# Ensure project root is visible
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = current_dir
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from uf_core.hardening import (
    evaluate_htc,
    HardeningEvaluationResult,
    KernelStatusFlags,
)


def main():
    result = evaluate_htc()

    print("HardeningEvaluationResult instance:")
    print(result)

    # Structural checks
    print("\nType checks:")
    print("Is HardeningEvaluationResult:", isinstance(result, HardeningEvaluationResult))
    print("Flags correct type:", isinstance(result.flags, KernelStatusFlags))
    print("raw_metrics is dict:", isinstance(result.raw_metrics, dict))
    print("notes is list:", isinstance(result.notes, list))

    print("\nDefault values:")
    print("flags =", result.flags)
    print("raw_metrics =", result.raw_metrics)
    print("notes =", result.notes)


if __name__ == "__main__":
    main()
