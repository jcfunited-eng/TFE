from typing import Dict

import pandas as pd


def backtest_static_allocation(
    price_history: pd.DataFrame,
    weights: Dict[str, float],
    initial_value: float = 10_000.0,
) -> pd.DataFrame:
    """
    Simple backtest: static allocation with daily rebalancing.

    price_history:
        DataFrame indexed by date, columns = tickers, values = close prices.

    weights:
        {ticker: target_weight} that sum approximately to 1.0.

    Returns:
        DataFrame with columns:
            - equity: portfolio value over time
            - portfolio_return: daily pct return
    """
    price_history = price_history.sort_index()
    returns = price_history.pct_change().dropna()

    # Align weights to available columns
    w_series = pd.Series({t: float(w) for t, w in weights.items()})
    w_series = w_series.reindex(returns.columns).fillna(0.0)

    portfolio_returns = (returns * w_series).sum(axis=1)
    equity = (1.0 + portfolio_returns).cumprod() * initial_value

    result = pd.DataFrame(
        {
            "equity": equity,
            "portfolio_return": portfolio_returns,
        }
    )
    return result
