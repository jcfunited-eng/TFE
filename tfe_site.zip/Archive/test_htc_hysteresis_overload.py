"""
Test for Hardening Trigger Condition HTC-3 (Hysteresis Overload).

We supply a synthetic stability_scores with:
    hysteresis_rate = 0.6   (> threshold 0.25)

Expected:
    flags.hysteresis_overload == True
    raw_metrics['hysteresis_rate'] == 0.6
    notes contains 'Hysteresis rate above threshold (0.25)'

And:
    flags.dsf_collapse == False
    flags.directional_collapse == False
"""

import os
import sys

# Ensure project root on path
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = current_dir
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from uf_core.hardening import evaluate_htc, KernelStatusFlags, HardeningEvaluationResult


def main():
    stability_scores = {
        "hysteresis_rate": 0.6
    }

    result = evaluate_htc(stability_scores=stability_scores)

    print("HTC-3 Hysteresis Overload Test Result:")
    print(result)

    print("\nFlags:", result.flags)
    print("Raw metrics:", result.raw_metrics)
    print("Notes:", result.notes)

    print("\nExplicit Checks:")
    print("Hysteresis Overload Flag (should be True):", result.flags.hysteresis_overload)
    print("Stored Hysteresis Rate:", result.raw_metrics.get("hysteresis_rate"))
    print(
        "Has hysteresis overload note:",
        any("Hysteresis rate above threshold" in note for note in result.notes),
    )
    print("\nDSF Collapse Flag (should be False):", result.flags.dsf_collapse)
    print("Directional Collapse Flag (should be False):", result.flags.directional_collapse)


if __name__ == "__main__":
    main()
