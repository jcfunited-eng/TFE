"""
Test Hardening Controller — SafeMode logic only.

Covers:
1) No severe HTC → SafeMode OFF.
2) Severe HTC → SafeMode ON + DSF suppression + frozen gates.
3) SafeMode stays ON across steps and preserves frozen gates.
"""

import os
import sys

# Ensure project root importable
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = current_dir
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from uf_core.hardening import KernelStatusFlags, HardeningEvaluationResult
from uf_core.safemode import SafeModeState
from uf_core.hardening_controller import hardening_control_step
from uf_core.layer1 import Gate
from uf_core.layer4 import DSF


def make_sample_dsf():
    return [
        DSF(gate=None, D_k=1, M_k=2, R_rev_k=3, U_star_k=0.8, P_k=4, B_k=5),
        DSF(gate=None, D_k=-1, M_k=-2, R_rev_k=-3, U_star_k=0.6, P_k=-4, B_k=-5),
    ]


def make_gates_a():
    return [
        Gate(start_idx=0, end_idx=10),
        Gate(start_idx=11, end_idx=20),
    ]


def main():
    print("=== Hardening Controller SafeMode Test ===\n")

    dsf = make_sample_dsf()
    gates = make_gates_a()

    # ----------------------------------------------------------
    # Case 1: No severe flags → SafeMode remains OFF
    # ----------------------------------------------------------
    stability_scores1 = {"dsf": 0.5}  # No collapse
    composite_metrics1 = {"S_UF": 0.7, "R_UF": 0.3}
    sensitivity_data = [{}]  # minimal

    state1 = SafeModeState(safe_mode=False)

    new_dsf1, new_gates1, new_state1, htc1 = hardening_control_step(
        current_step=1,
        dsf_list=dsf,
        gates=gates,
        composite_metrics=composite_metrics1,
        stability_scores=stability_scores1,
        sensitivity_data=sensitivity_data,
        safemode_state=state1,
    )

    print("Case 1 — SafeMode OFF:")
    print("safe_mode:", new_state1.safe_mode)
    print("DSF unchanged:", new_dsf1)
    print("Gates unchanged:", new_gates1)

    # ----------------------------------------------------------
    # Case 2: Severe flag → SafeMode ON
    # ----------------------------------------------------------
    stability_scores2 = {"dsf": 0.1}  # DSF collapse
    composite_metrics2 = {"S_UF": 0.4, "R_UF": 0.1}

    new_dsf2, new_gates2, new_state2, htc2 = hardening_control_step(
        current_step=2,
        dsf_list=dsf,
        gates=gates,
        composite_metrics=composite_metrics2,
        stability_scores=stability_scores2,
        sensitivity_data=sensitivity_data,
        safemode_state=new_state1,
    )

    print("\nCase 2 — SafeMode ON:")
    print("safe_mode:", new_state2.safe_mode)
    print("Suppressed DSF:", new_dsf2)
    print("Frozen Gates:", new_state2.frozen_gates)

    # ----------------------------------------------------------
    # Case 3: Already in SafeMode → preserve frozen gates
    # ----------------------------------------------------------
    new_dsf3, new_gates3, new_state3, htc3 = hardening_control_step(
        current_step=3,
        dsf_list=dsf,
        gates=gates,   # different gates should be IGNORED
        composite_metrics=composite_metrics2,
        stability_scores=stability_scores2,
        sensitivity_data=sensitivity_data,
        safemode_state=new_state2,
    )

    print("\nCase 3 — SafeMode persists:")
    print("safe_mode:", new_state3.safe_mode)
    print("Frozen Gates preserved:", new_state3.frozen_gates)
    print("Suppressed DSF:", new_dsf3)


if __name__ == "__main__":
    main()
