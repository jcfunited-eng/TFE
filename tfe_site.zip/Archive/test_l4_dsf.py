import pandas as pd

from uf_core.layer0 import compute_sev_series
from uf_core.layer1 import segment_gates
from uf_core.layer2 import interpret_gates
from uf_core.layer3 import compute_resonance
from uf_core.layer4 import compute_directional_signal, compute_dsf


def main():
    prices = [100, 101, 102, 110, 111, 112, 113, 90, 91, 92, 93, 94]
    df = pd.DataFrame({"Close": prices})

    # L0 → L3
    sev_list = compute_sev_series(df)
    gates = segment_gates(sev_list)
    interpretations = interpret_gates(sev_list, gates)
    resonance_results = compute_resonance(interpretations)

    # L4: DecisionState
    decision_states = compute_directional_signal(resonance_results)

    # DSF
    dsf_list = compute_dsf(decision_states)

    print("Total gates:", len(gates))
    print("Total decision states:", len(decision_states))
    print("Total DSF entries:", len(dsf_list), "\n")

    for idx, dsf in enumerate(dsf_list, start=1):
        gate = dsf.gate
        print(f"Gate {idx}:")
        print(f" Index range = [{gate.start_idx}, {gate.end_idx}]")
        print(f" D_k         = {dsf.D_k}")
        print(f" M_k         = {dsf.M_k}")
        print(f" R_rev_k     = {dsf.R_rev_k}")
        print(f" U*_k        = {dsf.U_star_k:.6f}")
        print(f" P_k         = {dsf.P_k}")
        print(f" B_k         = {dsf.B_k}\n")


if __name__ == "__main__":
    main()
