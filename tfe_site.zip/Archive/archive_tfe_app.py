import streamlit as st
import pandas as pd
import plotly.graph_objects as go

import data_loader
import portfolio
import risk
import market as mkt  # SMA, EMA, MACD, RSI, Bollinger, momentum


# ===================================================
# PAGE SETUP — clean, stable, dark-ish charts
# ===================================================

st.set_page_config(
    page_title="Tao Financial Engine",
    layout="wide",
)

PLOTLY_TEMPLATE = "plotly_dark"
UP_COLOR = "#00B050"
DOWN_COLOR = "#C00000"
LINE_COLOR = "#4a90e2"


# ===================================================
# DATA HELPERS
# ===================================================

@st.cache_data(show_spinner=False)
def get_portfolio_and_prices():
    """
    Load portfolio.csv and compute snapshot + latest prices.
    Expected columns in portfolio.csv:
      - ticker
      - quantity
      - cost_basis
    Extra columns (like asset_type) are ignored.
    """
    df = pd.read_csv("portfolio.csv")
    # Normalize column names if needed
    cols = [c.lower() for c in df.columns]
    df.columns = cols

    # Make sure we have ticker, quantity, cost_basis
    if "ticker" not in df.columns or "quantity" not in df.columns or "cost_basis" not in df.columns:
        raise ValueError("portfolio.csv must have columns: ticker, quantity, cost_basis")

    positions = df[["ticker", "quantity", "cost_basis"]].copy()
    tickers = list(positions["ticker"])
    latest = data_loader.latest_prices(tickers)
    snap = portfolio.compute_portfolio_snapshot(positions, latest)
    return positions, tickers, latest, snap


@st.cache_data(show_spinner=False)
def get_history_with_indicators(ticker: str):
    df = data_loader.load_price_history(ticker)
    close = df["close"]

    # indicators
    sma_20 = mkt.sma(close, 20)
    ema_20 = mkt.ema(close, 20)
    bb_mid, bb_up, bb_down = mkt.bollinger_bands(close, 20, 2.0)
    rsi_14 = mkt.rsi(close, 14)
    macd_line, macd_signal = mkt.macd(close)
    mom_10 = mkt.momentum(close, 10)

    # risk metrics
    rets = risk.daily_returns(close)
    vol = risk.annualized_volatility(rets)
    sharpe = risk.sharpe_ratio(rets, risk_free_rate=0.02)
    equity = (1 + rets).cumprod() * 10_000
    max_dd, dd_days = risk.max_drawdown(equity)

    indicators = {
        "sma_20": sma_20,
        "ema_20": ema_20,
        "bb_mid": bb_mid,
        "bb_up": bb_up,
        "bb_down": bb_down,
        "rsi_14": rsi_14,
        "macd_line": macd_line,
        "macd_signal": macd_signal,
        "momentum_10": mom_10,
        "returns": rets,
        "volatility": vol,
        "sharpe": sharpe,
        "max_dd": max_dd,
        "dd_days": dd_days,
    }

    return df, indicators


# ===================================================
# UTILITIES
# ===================================================

def normalize_df(df: pd.DataFrame):
    df2 = df.copy()
    if isinstance(df2.index, pd.DatetimeIndex):
        df2["date"] = df2.index
    else:
        df2["date"] = pd.to_datetime(df2.index, errors="coerce")
    df2 = df2.sort_values("date")
    return df2.set_index("date")


def classify_asset_type(ticker: str) -> str:
    if ticker.endswith("-USD"):
        return "crypto"
    if ticker.startswith("^"):
        return "index"
    return "equity"


def render_indicator_summary(ind: dict):
    vol = ind["volatility"]
    sharpe = ind["sharpe"]
    max_dd = ind["max_dd"]
    rsi_last = ind["rsi_14"].iloc[-1] if not ind["rsi_14"].dropna().empty else None

    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Volatility", f"{vol:.2%}")
    col2.metric("Sharpe (2% RF)", f"{sharpe:.2f}")
    col3.metric("Max Drawdown", f"{max_dd:.2%}")
    col4.metric("RSI (14)", f"{rsi_last:.1f}" if rsi_last else "N/A")

    st.write("")
    # Interpretations (T2 tone)
    if rsi_last:
        if rsi_last > 70:
            st.write("• RSI indicates overbought conditions.")
        elif rsi_last < 30:
            st.write("• RSI indicates oversold conditions.")
        else:
            st.write("• RSI is neutral.")

    if sharpe > 1:
        st.write("• Strong risk-adjusted performance.")
    elif sharpe < 0:
        st.write("• Negative risk-adjusted performance.")
    else:
        st.write("• Neutral risk-adjusted performance.")


def render_charts(ticker: str, df: pd.DataFrame, ind: dict):
    df_chart = normalize_df(df)

    sma_20 = ind["sma_20"]
    ema_20 = ind["ema_20"]
    bb_mid = ind["bb_mid"]
    bb_up = ind["bb_up"]
    bb_down = ind["bb_down"]
    rsi = ind["rsi_14"]
    macd_line = ind["macd_line"]
    macd_signal = ind["macd_signal"]
    mom = ind["momentum_10"]

    # PRICE
    st.subheader(f"Price & Trend — {ticker}")
    fig_price = go.Figure()

    fig_price.add_trace(go.Candlestick(
        x=df_chart.index,
        open=df_chart["open"],
        high=df_chart["high"],
        low=df_chart["low"],
        close=df_chart["close"],
        increasing_line_color=UP_COLOR,
        decreasing_line_color=DOWN_COLOR,
    ))

    fig_price.add_trace(go.Scatter(x=df_chart.index, y=sma_20, name="SMA 20",
                                   line=dict(color="#FFD700")))
    fig_price.add_trace(go.Scatter(x=df_chart.index, y=ema_20, name="EMA 20",
                                   line=dict(color="#4a90e2")))

    fig_price.add_trace(go.Scatter(x=df_chart.index, y=bb_up, name="BB Upper",
                                   line=dict(color="#AAAAAA", dash="dot")))
    fig_price.add_trace(go.Scatter(x=df_chart.index, y=bb_mid, name="BB Middle",
                                   line=dict(color="#888888", dash="dot")))
    fig_price.add_trace(go.Scatter(x=df_chart.index, y=bb_down, name="BB Lower",
                                   line=dict(color="#AAAAAA", dash="dot")))

    fig_price.update_layout(template=PLOTLY_TEMPLATE)
    st.plotly_chart(fig_price, use_container_width=True)

    # VOLUME
    st.subheader("Volume")
    fig_vol = go.Figure()
    fig_vol.add_trace(go.Bar(x=df_chart.index, y=df_chart["volume"],
                             marker=dict(color="#888888")))
    fig_vol.update_layout(template=PLOTLY_TEMPLATE)
    st.plotly_chart(fig_vol, use_container_width=True)

    # RSI
    st.subheader("RSI")
    fig_rsi = go.Figure()
    fig_rsi.add_trace(go.Scatter(x=df_chart.index, y=rsi,
                                 line=dict(color="#4a90e2")))
    fig_rsi.add_hline(y=70, line_color="red", line_dash="dot")
    fig_rsi.add_hline(y=30, line_color="green", line_dash="dot")
    fig_rsi.update_layout(template=PLOTLY_TEMPLATE)
    st.plotly_chart(fig_rsi, use_container_width=True)

    # MACD
    st.subheader("MACD")
    fig_macd = go.Figure()
    fig_macd.add_trace(go.Scatter(x=df_chart.index, y=macd_line,
                                  line=dict(color="#4a90e2")))
    fig_macd.add_trace(go.Scatter(x=df_chart.index, y=macd_signal,
                                  line=dict(color="#AAAAAA", dash="dot")))
    fig_macd.update_layout(template=PLOTLY_TEMPLATE)
    st.plotly_chart(fig_macd, use_container_width=True)

    # MOMENTUM
    st.subheader("Momentum")
    fig_mom = go.Figure()
    fig_mom.add_trace(go.Scatter(x=df_chart.index, y=mom,
                                 line=dict(color="#4a90e2")))
    fig_mom.update_layout(template=PLOTLY_TEMPLATE)
    st.plotly_chart(fig_mom, use_container_width=True)


# ===================================================
# RECOMMENDATION ENGINE (FFM/RRE style)
# ===================================================

@st.cache_data(show_spinner=False)
def build_recommendations(positions: pd.DataFrame):
    """
    Build basic portfolio actions + opportunity lists
    from portfolio tickers + small watchlist.
    """

    portfolio_tickers = list(positions["ticker"])
    watchlist = [
        "AAPL", "MSFT", "NVDA", "VTI", "VOO", "SPY",
        "^GSPC", "^IXIC",
        "BTC-USD", "ETH-USD",
    ]
    universe = sorted(set(portfolio_tickers + watchlist))

    rows = []
    for t in universe:
        try:
            df, ind = get_history_with_indicators(t)
        except Exception:
            continue

        vol = ind["volatility"]
        sharpe = ind["sharpe"]
        max_dd = ind["max_dd"]
        rsi = ind["rsi_14"].iloc[-1] if not ind["rsi_14"].dropna().empty else None
        mom = ind["momentum_10"].iloc[-1] if not ind["momentum_10"].dropna().empty else None

        score = 0.0
        notes = []

        # momentum
        if mom is not None:
            if mom > 0.05:
                score += 2
                notes.append("strong positive momentum")
            elif mom > 0:
                score += 1
                notes.append("mild positive momentum")
            elif mom < -0.05:
                score -= 1
                notes.append("negative momentum")

        # sharpe
        if sharpe > 1.0:
            score += 2
            notes.append("good risk-adjusted return")
        elif sharpe > 0:
            score += 1
            notes.append("mild risk-adjusted return")
        elif sharpe < 0:
            score -= 1
            notes.append("negative risk-adjusted return")

        # volatility
        if vol < 0.15:
            score += 1
            notes.append("low volatility")
        elif vol > 0.40:
            score -= 1
            notes.append("high volatility")

        # RSI
        if rsi is not None:
            if 40 <= rsi <= 60:
                score += 1
                notes.append("RSI neutral")
            elif rsi < 30:
                notes.append("RSI oversold")
            elif rsi > 70:
                score -= 1
                notes.append("RSI overbought")

        asset_type = classify_asset_type(ticker=t)

        rows.append({
            "ticker": t,
            "asset_type": asset_type,
            "score": score,
            "volatility": vol,
            "sharpe": sharpe,
            "max_dd": max_dd,
            "rsi": rsi,
            "momentum": mom,
            "notes": "; ".join(notes),
        })

    if not rows:
        return [], pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

    df_all = pd.DataFrame(rows).sort_values("score", ascending=False)

    high = df_all[df_all["score"] >= 3].head(3)
    medium = df_all[(df_all["score"] >= 1) & (df_all["score"] < 3)].head(5)
    low = df_all[df_all["score"] < 1].head(5)

    # Portfolio actions
    actions = []
    if not positions.empty:
        _, _, latest_prices, snap = get_portfolio_and_prices()
        weights = snap.weights

        for _, row in positions.iterrows():
            t = row["ticker"]
            w = weights.get(t, 0)
            asset_type = classify_asset_type(t)

            try:
                _, ind = get_history_with_indicators(t)
            except Exception:
                continue

            vol = ind["volatility"]
            sharpe = ind["sharpe"]
            rsi = ind["rsi_14"].iloc[-1] if not ind["rsi_14"].dropna().empty else None

            if w > 0.40:
                action = "Trim slightly (overweight position)."
            elif sharpe > 1 and vol < 0.25:
                action = "Hold. Solid long-term profile."
            elif sharpe > 0 and vol < 0.30:
                action = "Hold or add slowly if adding funds."
            elif sharpe < 0:
                action = "Hold cautiously. Review reasons for owning this asset."
            else:
                action = "Hold. No strong signals."

            if asset_type == "crypto" and vol > 0.40:
                action += " Crypto volatility elevated; avoid large changes."

            actions.append({
                "ticker": t,
                "weight": w,
                "asset_type": asset_type,
                "action": action,
                "sharpe": sharpe,
                "volatility": vol,
                "rsi": rsi,
            })

    return actions, high, medium, low


# ===================================================
# PAGES
# ===================================================

def render_dashboard():
    st.title("📊 Tao Financial Engine — Dashboard")

    positions, tickers, latest, snap = get_portfolio_and_prices()

    st.subheader("Portfolio Snapshot")
    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Total Value", f"${snap.total_value:,.2f}")
    col2.metric("Unrealized P/L", f"{snap.unrealized_pl:,.2f}", f"{snap.unrealized_pl_pct:.2%}")
    col3.metric("Diversification", f"{snap.diversification_score:.2f}")
    col4.metric("Assets", len(snap.weights))

    st.write("**Weights:**")
    st.json(snap.weights)

    st.subheader("Latest Prices")
    st.json(latest)

    st.subheader("Risk Metrics per Asset")
    for ticker in tickers:
        st.markdown(f"### {ticker}")
        df, ind = get_history_with_indicators(ticker)
        render_indicator_summary(ind)
        st.markdown("---")


def render_lookup():
    st.title("🔍 Ticker Lookup — Multi-Chart Insight")

    ticker = st.text_input("Ticker (AAPL, BTC-USD, VTI, ^GSPC):", "AAPL").upper().strip()
    if not ticker:
        return

    st.subheader("Latest Price")
    latest = data_loader.latest_prices([ticker])
    if ticker in latest:
        st.metric("Last Price", f"{latest[ticker]:,.4f}")

    df, ind = get_history_with_indicators(ticker)

    st.subheader("Indicators & Risk")
    render_indicator_summary(ind)

    render_charts(ticker, df, ind)


def render_recommendations():
    st.title("⭐ Recommendations")

    positions, tickers, latest, snap = get_portfolio_and_prices()
    actions, high, medium, low = build_recommendations(positions)

    st.subheader("Portfolio Actions (Holdings Only)")
    if actions:
        for a in actions:
            st.markdown(f"### {a['ticker']} — weight: {a['weight']:.0%}")
            st.write(a["action"])
            st.write(
                f"Volatility: {a['volatility']:.2%}, Sharpe: {a['sharpe']:.2f}"
            )
            st.markdown("---")
    else:
        st.write("No portfolio actions available.")

    st.subheader("Opportunity Filters")
    filter_choice = st.selectbox(
        "View opportunities for:",
        ["All", "Equities", "Crypto", "Indexes"],
        index=0,
    )

    def filter_df(df):
        if df is None or df.empty:
            return df
        if filter_choice == "All":
            return df
        if filter_choice == "Equities":
            return df[df["asset_type"] == "equity"]
        if filter_choice == "Crypto":
            return df[df["asset_type"] == "crypto"]
        if filter_choice == "Indexes":
            return df[df["asset_type"] == "index"]
        return df

    # High conviction
    st.subheader("High Conviction Opportunities (1–3)")
    f_high = filter_df(high)
    if f_high is not None and not f_high.empty:
        for _, row in f_high.iterrows():
            st.markdown(f"### {row['ticker']} — score {row['score']:.1f}")
            st.write(row["notes"] or "Signals positive overall.")
            st.write(
                f"Volatility: {row['volatility']:.2%}, "
                f"Sharpe: {row['sharpe']:.2f}, "
                f"Max Drawdown: {row['max_dd']:.2%}"
            )
            st.markdown("---")
    else:
        st.write("No high conviction ideas match the filter.")

    # Medium
    st.subheader("Medium Opportunities (3–5)")
    f_med = filter_df(medium)
    if f_med is not None and not f_med.empty:
        st.dataframe(
            f_med[["ticker", "asset_type", "score", "volatility", "sharpe", "max_dd", "notes"]],
            use_container_width=True,
        )
    else:
        st.write("No medium opportunities match the filter.")

    # Low
    st.subheader("Speculative / Low-Confidence Ideas (3–5)")
    f_low = filter_df(low)
    if f_low is not None and not f_low.empty:
        st.dataframe(
            f_low[["ticker", "asset_type", "score", "volatility", "sharpe", "max_dd", "notes"]],
            use_container_width=True,
        )
    else:
        st.write("No speculative ideas match the filter.")


def render_portfolio_manager():
    st.title("🧺 Portfolio Manager")

    try:
        positions, tickers, latest, snap = get_portfolio_and_prices()
    except Exception as e:
        st.error(f"Error loading portfolio: {e}")
        return

    st.write("Manage the contents of your portfolio file (portfolio.csv).")

    tab_add, tab_remove, tab_update = st.tabs(["➕ Add Asset", "🗑 Remove Asset", "✏️ Update Asset"])

    # ADD ASSET
    with tab_add:
        st.subheader("Add Asset")

        new_ticker = st.text_input("Ticker (e.g., AAPL, BTC-USD, VTI):", key="add_ticker")
        new_qty = st.number_input("Quantity (shares/units)", min_value=0.0, format="%.4f", key="add_qty")
        new_cost = st.number_input("Cost Basis per Unit ($)", min_value=0.0, format="%.4f", key="add_cost")

        if st.button("Add to Portfolio"):
            if new_ticker.strip() == "":
                st.error("Ticker cannot be empty.")
            else:
                df = pd.read_csv("portfolio.csv")
                cols = [c.lower() for c in df.columns]
                df.columns = cols
                row = {"ticker": new_ticker.upper(), "quantity": new_qty, "cost_basis": new_cost}
                # Keep extra columns if they exist
                for c in df.columns:
                    if c not in row:
                        row[c] = None
                df = df.append(row, ignore_index=True)
                df.to_csv("portfolio.csv", index=False)
                st.success(f"Added {new_ticker.upper()} to portfolio.")
                st.experimental_rerun()

    # REMOVE ASSET
    with tab_remove:
        st.subheader("Remove Asset")

        if not tickers:
            st.info("Portfolio is empty.")
        else:
            rm_ticker = st.selectbox("Select asset to remove", tickers, key="remove_ticker")
            if st.button("Remove Asset"):
                df = pd.read_csv("portfolio.csv")
                cols = [c.lower() for c in df.columns]
                df.columns = cols
                df = df[df["ticker"] != rm_ticker]
                df.to_csv("portfolio.csv", index=False)
                st.success(f"Removed {rm_ticker} from portfolio.")
                st.experimental_rerun()

    # UPDATE ASSET
    with tab_update:
        st.subheader("Update Asset")

        if not tickers:
            st.info("Portfolio is empty.")
        else:
            up_ticker = st.selectbox("Select asset to update", tickers, key="update_ticker")
            df = pd.read_csv("portfolio.csv")
            cols = [c.lower() for c in df.columns]
            df.columns = cols
            row = df[df["ticker"] == up_ticker].iloc[0]

            current_qty = float(row["quantity"])
            current_cost = float(row["cost_basis"])

            new_qty = st.number_input(
                "Quantity (shares/units)",
                min_value=0.0,
                value=current_qty,
                format="%.4f",
                key="update_qty",
            )
            new_cost = st.number_input(
                "Cost Basis per Unit ($)",
                min_value=0.0,
                value=current_cost,
                format="%.4f",
                key="update_cost",
            )

            if st.button("Update Asset"):
                df.loc[df["ticker"] == up_ticker, "quantity"] = new_qty
                df.loc[df["ticker"] == up_ticker, "cost_basis"] = new_cost
                df.to_csv("portfolio.csv", index=False)
                st.success(f"Updated {up_ticker}.")
                st.experimental_rerun()


def render_mom_mode():
    st.title("🧸 Mom Mode — Simple View")

    try:
        positions, tickers, latest, snap = get_portfolio_and_prices()
        actions, high, medium, low = build_recommendations(positions)
    except Exception as e:
        st.error(f"Problem loading data: {e}")
        return

    if positions.empty:
        st.info("Your portfolio is empty. Add assets in the Portfolio Manager.")
        return

    # Overall status: Green / Yellow / Red
    pl_pct = snap.unrealized_pl_pct
    div_score = snap.diversification_score
    avg_vol = 0.0
    if actions:
        avg_vol = sum(a["volatility"] for a in actions) / len(actions)

    # Simple status logic
    if pl_pct > 0.05 and avg_vol < 0.30:
        status = "GREEN"
        status_msg = "Portfolio is performing well with manageable risk."
    elif pl_pct < -0.10 or avg_vol > 0.45:
        status = "RED"
        status_msg = "There is elevated risk or recent losses to pay attention to."
    else:
        status = "YELLOW"
        status_msg = "Nothing urgent, but conditions are mixed. Worth monitoring."

    if div_score < 0.2:
        status = "YELLOW" if status == "GREEN" else status
        status_msg += " Diversification is low; portfolio is concentrated."

    st.subheader("Overall Status")
    st.write(f"**Your portfolio today:** {status}")
    st.write(status_msg)

    st.subheader("Most Important Thing")
    if status == "GREEN":
        st.write("You are generally on track. No major changes are needed.")
    elif status == "YELLOW":
        st.write("Conditions are mixed. Review key holdings but avoid hasty decisions.")
    else:
        st.write("There is meaningful risk. Focus on keeping positions aligned with your comfort level.")

    # Top suggestion from portfolio actions
    st.subheader("Top Suggestion")
    top_action = None
    if actions:
        # pick the asset with largest weight or first overweight/crypto with note
        sorted_actions = sorted(actions, key=lambda a: a["weight"], reverse=True)
        top_action = sorted_actions[0]
        st.write(f"For **{top_action['ticker']}**: {top_action['action']}")
    else:
        st.write("No specific action is suggested today.")

    # Opportunities (simplified)
    st.subheader("Opportunities")
    if high is not None and not high.empty:
        st.write("High conviction ideas:")
        for _, row in high.head(2).iterrows():
            st.write(f"- **{row['ticker']}** — {row['notes'] or 'Signals positive overall.'}")
    elif medium is not None and not medium.empty:
        st.write("Medium conviction ideas:")
        for _, row in medium.head(2).iterrows():
            st.write(f"- **{row['ticker']}** — {row['notes'] or 'Signals moderately positive.'}")
    else:
        st.write("No clear new opportunities stand out today.")

    # Risks (simplified)
    st.subheader("Key Risks")
    risk_notes = []
    for a in actions:
        if a["asset_type"] == "crypto" and a["volatility"] > 0.40:
            risk_notes.append(f"{a['ticker']}: high volatility in crypto.")
        if a["weight"] > 0.40:
            risk_notes.append(f"{a['ticker']}: large share of portfolio.")

    if risk_notes:
        for r in risk_notes:
            st.write(f"- {r}")
    else:
        st.write("No major risks beyond normal market movement.")

    st.write("")
    st.write("This view is simplified and informational. Final decisions should always follow Tao's judgment and comfort level.")


# ===================================================
# ROUTER
# ===================================================

page = st.sidebar.radio(
    "Page",
    ["📊 Dashboard", "🔍 Ticker Lookup", "⭐ Recommendations", "🧺 Portfolio Manager", "🧸 Mom Mode"],
)

if page == "📊 Dashboard":
    render_dashboard()
elif page == "🔍 Ticker Lookup":
    render_lookup()
elif page == "⭐ Recommendations":
    render_recommendations()
elif page == "🧺 Portfolio Manager":
    render_portfolio_manager()
else:
    render_mom_mode()
