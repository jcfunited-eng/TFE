"""
Test for Hardening Trigger Condition HTC-5 (Composite Metric Collapse).

We supply synthetic composite_metrics:
    S_UF = 0.45  (< S_UF_MIN = 0.50)
    R_UF = 0.10  (< R_UF_MIN = 0.15)

Expected:
    flags.composite_S_low == True
    flags.composite_R_low == True
    raw_metrics['S_UF'] == 0.45
    raw_metrics['R_UF'] == 0.10

Other flags (dsf_collapse, directional_collapse, hysteresis_overload,
breathing_instability) should remain False.
"""

import os
import sys

# Ensure project root on sys.path
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = current_dir
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from uf_core.hardening import evaluate_htc, KernelStatusFlags, HardeningEvaluationResult


def main():
    composite_metrics = {
        "S_UF": 0.45,
        "R_UF": 0.10,
    }

    result = evaluate_htc(composite_metrics=composite_metrics)

    print("HTC-5 Composite Collapse Test Result:")
    print(result)

    print("\nFlags:", result.flags)
    print("Raw metrics:", result.raw_metrics)
    print("Notes:", result.notes)

    print("\nExplicit Checks:")
    print("Composite S_low Flag (should be True):", result.flags.composite_S_low)
    print("Composite R_low Flag (should be True):", result.flags.composite_R_low)
    print("Stored S_UF:", result.raw_metrics.get("S_UF"))
    print("Stored R_UF:", result.raw_metrics.get("R_UF"))
    print(
        "Has S(UF) collapse note:",
        any("S(UF) below threshold" in note for note in result.notes),
    )
    print(
        "Has R(UF) collapse note:",
        any("R(UF) below threshold" in note for note in result.notes),
    )

    # Confirm no other flags were tripped
    print("\nDSF Collapse Flag (should be False):", result.flags.dsf_collapse)
    print("Directional Collapse Flag (should be False):", result.flags.directional_collapse)
    print("Hysteresis Overload Flag (should be False):", result.flags.hysteresis_overload)
    print("Breathing Instability Flag (should be False):", result.flags.breathing_instability)


if __name__ == "__main__":
    main()
