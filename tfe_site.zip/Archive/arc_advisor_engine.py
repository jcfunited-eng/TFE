# advisor_engine.py
import pandas as pd


def load_portfolio(csv_path="portfolio.csv"):
    """
    Loads the portfolio CSV and normalizes column names.
    Ensures compatibility with the user's actual schema.
    """
    try:
        df = pd.read_csv(csv_path)

        # Normalize all column names (strip, lowercase)
        df.columns = [c.strip().lower() for c in df.columns]

        return df
    except Exception as e:
        print("Error loading portfolio:", e)
        return None


def compute_portfolio_insights(df):
    """
    Framework-pure:
    Analyzes the user's *existing* holdings only.
    """
    insights = {}

    # Expected normalized column names
    required = ["ticker", "quantity", "cost_basis"]

    for col in required:
        if col not in df.columns:
            raise KeyError(
                f"Portfolio missing required column: '{col}'. "
                f"Columns present: {list(df.columns)}"
            )

    # Compute value
    df["value"] = df["quantity"] * df["cost_basis"]
    total_value = df["value"].sum()

    # Allocation %
    df_alloc = df.copy()
    df_alloc["allocation"] = df_alloc["value"] / total_value * 100
    insights["allocations"] = df_alloc[["ticker", "allocation"]].to_dict(orient="records")

    # Concentration / largest holding
    top = df_alloc.sort_values("allocation", ascending=False).iloc[0]
    insights["top_holding"] = {
        "ticker": top["ticker"],
        "allocation": top["allocation"]
    }

    # Diversification level
    count = len(df)
    if count <= 3:
        div_score = "Low"
    elif 4 <= count <= 10:
        div_score = "Moderate"
    else:
        div_score = "High"

    insights["diversification"] = div_score

    # Narrative summary (hybrid tone)
    insights["summary"] = (
        f"Your portfolio contains **{count} positions** with a "
        f"**{div_score.lower()} diversification level**. "
        f"Your largest holding is **{top['ticker']}**, making up "
        f"**{top['allocation']:.1f}%** of your total portfolio value."
    )

    return insights
