"""
Corrected Hardening Controller — Non-SafeMode Tests
===================================================

All cases use fresh DSF and Gate objects to avoid contamination from earlier tests.

Cases:
1) HA-1 (Signal Suppression)
2) HA-3 (Gate Freeze)
3) HA-2 (Ramp-Down)
4) Normal Mode
"""

import os
import sys

# Ensure project root importable
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = current_dir
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from uf_core.hardening_controller import hardening_control_step
from uf_core.safemode import SafeModeState
from uf_core.layer4 import DSF
from uf_core.layer1 import Gate


def make_sample_dsf():
    return [
        DSF(gate=None, D_k=1.0, M_k=2.0, R_rev_k=3.0, U_star_k=0.8, P_k=4.0, B_k=5.0),
        DSF(gate=None, D_k=-1.0, M_k=-2.0, R_rev_k=-3.0, U_star_k=0.6, P_k=-4.0, B_k=-5.0),
    ]


def make_gates():
    return [
        Gate(start_idx=0, end_idx=10),
        Gate(start_idx=11, end_idx=20),
    ]


def main():
    print("=== Hardening Controller — Non-SafeMode Tests (Corrected) ===\n")

    sensitivity_min = [{}]  # minimal placeholder
    base_state = SafeModeState(safe_mode=False)

    # --------------------------------------------------
    # CASE 1 — HA-1 (Signal Suppression)
    # --------------------------------------------------
    dsf1 = make_sample_dsf()
    gates1 = make_gates()

    # Trigger directional collapse via synthetic sensitivity data
    stability_scores_HA1 = {"dsf": 0.5}
    composite_metrics_HA1 = {"S_UF": 0.7, "R_UF": 0.3}
    sensitivity_for_collapse = [{"directional": -1}]  # triggers directional collapse

    new_dsf1, new_gates1, new_state1, htc1 = hardening_control_step(
        current_step=1,
        dsf_list=dsf1,
        gates=gates1,
        composite_metrics=composite_metrics_HA1,
        stability_scores=stability_scores_HA1,
        sensitivity_data=sensitivity_for_collapse,
        safemode_state=base_state,
    )

    print("Case 1 — HA-1 (Signal Suppression):")
    for d in new_dsf1:
        print(d)
    print("Gates:", new_gates1)
    print("SafeMode:", new_state1.safe_mode, "\n")

    # --------------------------------------------------
    # CASE 2 — HA-3 (Gate Freeze)
    # --------------------------------------------------
    dsf2 = make_sample_dsf()
    gates2 = make_gates()

    # Trigger gate drift excess only
    stability_scores_HA3 = {"dsf": 0.5, "gate_drift_rate": 0.6}
    composite_metrics_HA3 = {"S_UF": 0.7, "R_UF": 0.3}

    new_dsf2, new_gates2, new_state2, htc2 = hardening_control_step(
        current_step=2,
        dsf_list=dsf2,
        gates=gates2,
        composite_metrics=composite_metrics_HA3,
        stability_scores=stability_scores_HA3,
        sensitivity_data=sensitivity_min,
        safemode_state=base_state,
    )

    print("Case 2 — HA-3 (Gate Freeze):")
    print("DSF (unchanged):")
    for d in new_dsf2:
        print(d)
    print("Frozen Gates (snapshot):")
    for g in new_gates2:
        print(g)
    print("SafeMode:", new_state2.safe_mode, "\n")

    # --------------------------------------------------
    # CASE 3 — HA-2 (Ramp-Down)
    # --------------------------------------------------
    dsf3 = make_sample_dsf()
    gates3 = make_gates()

    stability_scores_HA2 = {"dsf": 0.5, "directional": 0.2}  # triggers HA-2
    composite_metrics_HA2 = {"S_UF": 0.7, "R_UF": 0.3}

    new_dsf3, new_gates3, new_state3, htc3 = hardening_control_step(
        current_step=3,
        dsf_list=dsf3,
        gates=gates3,
        composite_metrics=composite_metrics_HA2,
        stability_scores=stability_scores_HA2,
        sensitivity_data=sensitivity_min,
        safemode_state=base_state,
    )

    print("Case 3 — HA-2 (Ramp-Down, φ=0.25):")
    for d in new_dsf3:
        print(d)
    print("Gates:", new_gates3)
    print("SafeMode:", new_state3.safe_mode, "\n")

    # --------------------------------------------------
    # CASE 4 — Normal Mode
    # --------------------------------------------------
    dsf4 = make_sample_dsf()
    gates4 = make_gates()

    stability_scores_normal = {"dsf": 0.6, "directional": 0.6}
    composite_metrics_normal = {"S_UF": 0.7, "R_UF": 0.3}

    new_dsf4, new_gates4, new_state4, htc4 = hardening_control_step(
        current_step=4,
        dsf_list=dsf4,
        gates=gates4,
        composite_metrics=composite_metrics_normal,
        stability_scores=stability_scores_normal,
        sensitivity_data=sensitivity_min,
        safemode_state=base_state,
    )

    print("Case 4 — Normal Mode:")
    for d in new_dsf4:
        print(d)
    print("Gates:", new_gates4)
    print("SafeMode:", new_state4.safe_mode)


if __name__ == "__main__":
    main()
