import pandas as pd

from uf_core.layer0 import compute_sev_series
from uf_core.layer1 import segment_gates
from uf_core.layer2 import interpret_gates
from uf_core.layer3 import compute_resonance
from uf_core.layer4 import compute_directional_signal
from uf_core.config import KERNEL_THRESHOLDS


def main():
    prices = [100, 101, 102, 110, 111, 112, 113, 90, 91, 92, 93, 94]
    df = pd.DataFrame({"Close": prices})

    sev_list = compute_sev_series(df)
    gates = segment_gates(sev_list)
    interpretations = interpret_gates(sev_list, gates)
    resonance_results = compute_resonance(interpretations)
    decision_states = compute_directional_signal(resonance_results)

    print("Total gates:", len(decision_states))
    print("epsilon_D =", KERNEL_THRESHOLDS.epsilon_D)
    print("Momentum rule: M_k = +1 if D_k = D_{k-1} = +1; -1 if D_k = D_{k-1} = -1; else 0\n")

    prev_D = None

    for idx, ds in enumerate(decision_states, start=1):
        res = ds.resonance_result
        gate = res.interpretation.gate
        R_k = res.R_k
        delta_R = ds.delta_R
        D_k = ds.D_k
        M_k = ds.M_k

        print(f"Gate {idx}:")
        print(f" Index range = [{gate.start_idx}, {gate.end_idx}]")
        print(f" R_k         = {R_k:.6f}")
        print(f" ΔR(k)       = {delta_R:.6f}")
        print(f" D_k         = {D_k}")
        print(f" M_k         = {M_k}")

        # Compute expected M_k for verification
        if prev_D is None:
            expected = 0
        else:
            if D_k == 1 and prev_D == 1:
                expected = 1
            elif D_k == -1 and prev_D == -1:
                expected = -1
            else:
                expected = 0

        print(f" Expected M_k = {expected}\n")
        prev_D = D_k


if __name__ == "__main__":
    main()
