import pandas as pd

from uf_core.layer0 import compute_sev_series
from uf_core.layer1 import segment_gates
from uf_core.layer2 import interpret_gates
from uf_core.layer3 import compute_resonance
from uf_core.layer4 import compute_directional_signal
from uf_core.config import KERNEL_THRESHOLDS


def main():
    prices = [100, 101, 102, 110, 111, 112, 113, 90, 91, 92, 93, 94]
    df = pd.DataFrame({"Close": prices})

    sev_list = compute_sev_series(df)
    gates = segment_gates(sev_list)
    interpretations = interpret_gates(sev_list, gates)
    resonance_results = compute_resonance(interpretations)
    decision_states = compute_directional_signal(resonance_results)

    print("Total gates:", len(decision_states))
    print("epsilon_D =", KERNEL_THRESHOLDS.epsilon_D)
    print("Pressure rule: P_k = +1 if ΔR>0 & |D_k|=1; -1 if ΔR<0 & |D_k|=1; else 0.\n")

    for idx, ds in enumerate(decision_states, start=1):
        res = ds.resonance_result
        gate = res.interpretation.gate

        delta_R = ds.delta_R
        D_k = ds.D_k
        P_k = ds.P_k

        # Expected computation
        if abs(D_k) == 1:
            if delta_R > 0:
                expected = 1
            elif delta_R < 0:
                expected = -1
            else:
                expected = 0
        else:
            expected = 0

        print(f"Gate {idx}:")
        print(f" Index range = [{gate.start_idx}, {gate.end_idx}]")
        print(f" ΔR(k)       = {delta_R:.6f}")
        print(f" D_k         = {D_k}")
        print(f" P_k         = {P_k}")
        print(f" Expected P_k= {expected}\n")


if __name__ == "__main__":
    main()
