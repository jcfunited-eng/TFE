"""
Test for Hardening Action HA-1 (Signal Suppression).

This test validates that when any critical hardening flag is raised,
the DSF structural/action signals are suppressed:

    D_k → 0
    M_k → 0
    R_rev_k → 0
    P_k → 0
    B_k → 0
    U*_k remains unchanged.

Also tests that when no critical flags are raised,
the DSF list is returned unchanged.
"""

import os
import sys

# Ensure project root is importable
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = current_dir
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from uf_core.hardening import (
    KernelStatusFlags,
    HardeningEvaluationResult,
)
from uf_core.layer4 import DSF
from uf_core.hardening_actions import apply_signal_suppression


def make_sample_dsf():
    """Return a list of sample DSF entries with non-zero values."""
    return [
        DSF(
            gate=None,      # Gate object isn't used by the suppression logic
            D_k=1,
            M_k=1,
            R_rev_k=1,
            U_star_k=0.75,
            P_k=1,
            B_k=1,
        ),
        DSF(
            gate=None,
            D_k=-1,
            M_k=-1,
            R_rev_k=-1,
            U_star_k=0.50,
            P_k=-1,
            B_k=-1,
        ),
    ]


def main():
    print("=== HA-1 Signal Suppression Test ===\n")

    # ----------------------------------------------------------
    # Case 1: Critical flag raised → suppression MUST occur
    # ----------------------------------------------------------

    dsf_list = make_sample_dsf()

    flags = KernelStatusFlags(
        dsf_collapse=True,  # critical flag triggered
    )
    htc_result = HardeningEvaluationResult(
        flags=flags,
        raw_metrics={},
        notes=[],
    )

    suppressed = apply_signal_suppression(htc_result, dsf_list)

    print("Suppressed DSF list (critical flag active):")
    for dsf in suppressed:
        print(dsf)

    print("\nExplicit Checks (suppression case):")
    for i, dsf in enumerate(suppressed):
        print(
            f"Entry {i}: D={dsf.D_k}, M={dsf.M_k}, R_rev={dsf.R_rev_k}, "
            f"P={dsf.P_k}, B={dsf.B_k}, U*={dsf.U_star_k}"
        )

    # ----------------------------------------------------------
    # Case 2: No critical flags → NO suppression should occur
    # ----------------------------------------------------------

    flags2 = KernelStatusFlags()   # all False
    htc_result2 = HardeningEvaluationResult(
        flags=flags2,
        raw_metrics={},
        notes=[],
    )

    unchanged = apply_signal_suppression(htc_result2, dsf_list)

    print("\nUnchanged DSF list (no critical flags):")
    for dsf in unchanged:
        print(dsf)

    print("\nExplicit Checks (no-suppression case):")
    for i, dsf in enumerate(unchanged):
        print(
            f"Entry {i}: D={dsf.D_k}, M={dsf.M_k}, R_rev={dsf.R_rev_k}, "
            f"P={dsf.P_k}, B={dsf.B_k}, U*={dsf.U_star_k}"
        )


if __name__ == "__main__":
    main()
