# app.py
# Master import hub for all pages

import streamlit as st

st.set_page_config(
    page_title="Tao Financial Engine",
    layout="wide",
)

# ------------------------------------------
# IMPORT SHARED FUNCTIONS + CONSTANTS
# ------------------------------------------
from utils import (
    get_portfolio_and_prices,
    get_history_range,
    UP_COLOR,
    DOWN_COLOR,
    PLOTLY_TEMPLATE,
)

from engine import (
    get_history_with_indicators,
)

# ------------------------------------------
# Main Landing Page
# ------------------------------------------
st.title("Tao Financial Engine")
st.write("Select a page using the navigation sidebar.")

# ------------------------------------------
# EXPORT PUBLIC SYMBOLS FOR PAGES
# ------------------------------------------
__all__ = [
    "get_portfolio_and_prices",
    "get_history_range",
    "get_history_with_indicators",
    "UP_COLOR",
    "DOWN_COLOR",
    "PLOTLY_TEMPLATE",
]
