"""
Test for should_attempt_recovery() in safemode.py (strict composite-only criteria).

Scenarios:
1) SafeMode inactive → should_return False.
2) SafeMode active, missing S_UF or R_UF → False.
3) SafeMode active, S_UF <= 0.60 or R_UF <= 0.20 → False.
4) SafeMode active, S_UF > 0.60 and R_UF > 0.20 → True.
"""

import os
import sys

# Ensure project root is importable
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = current_dir
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from uf_core.safemode import SafeModeState, should_attempt_recovery


def main():
    print("=== SafeMode Recovery Criteria Test ===\n")

    # Case 1: SafeMode inactive
    state1 = SafeModeState(safe_mode=False)
    cm = {"S_UF": 0.7, "R_UF": 0.3}
    ss = {}
    print("Case 1 — SafeMode inactive:")
    print("should_attempt_recovery:", should_attempt_recovery(state1, cm, ss))

    # Case 2: SafeMode active, missing S_UF/R_UF
    state2 = SafeModeState(safe_mode=True)
    cm2 = {"S_UF": 0.7}   # missing R_UF
    print("\nCase 2 — SafeMode active, missing R_UF:")
    print("should_attempt_recovery:", should_attempt_recovery(state2, cm2, ss))

    # Case 3: SafeMode active, S_UF or R_UF too low
    cm3 = {"S_UF": 0.60, "R_UF": 0.25}  # S_UF not > 0.60
    print("\nCase 3A — SafeMode active, S_UF too low:")
    print("should_attempt_recovery:", should_attempt_recovery(state2, cm3, ss))

    cm4 = {"S_UF": 0.70, "R_UF": 0.20}  # R_UF not > 0.20
    print("\nCase 3B — SafeMode active, R_UF too low:")
    print("should_attempt_recovery:", should_attempt_recovery(state2, cm4, ss))

    # Case 4: SafeMode active, S_UF > 0.60 and R_UF > 0.20
    cm5 = {"S_UF": 0.75, "R_UF": 0.30}
    print("\nCase 4 — SafeMode active, both above thresholds:")
    print("should_attempt_recovery:", should_attempt_recovery(state2, cm5, ss))


if __name__ == "__main__":
    main()
