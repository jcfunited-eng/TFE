"""
Test for Hardening Trigger Condition HTC-4 (Breathing Instability).

We supply a synthetic stability_scores with:
    breathing_rate = 0.6   (> threshold 0.20)

Expected:
    flags.breathing_instability == True
    raw_metrics['breathing_rate'] == 0.6
    notes contains 'Breathing rate above threshold (0.2)'

And:
    flags.dsf_collapse == False
    flags.directional_collapse == False
    flags.hysteresis_overload == False
"""

import os
import sys

# Ensure project root on path
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = current_dir
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from uf_core.hardening import evaluate_htc, HardeningEvaluationResult, KernelStatusFlags


def main():
    stability_scores = {
        "breathing_rate": 0.6
    }

    result = evaluate_htc(stability_scores=stability_scores)

    print("HTC-4 Breathing Instability Test Result:")
    print(result)

    print("\nFlags:", result.flags)
    print("Raw metrics:", result.raw_metrics)
    print("Notes:", result.notes)

    print("\nExplicit Checks:")
    print("Breathing Instability Flag (should be True):", result.flags.breathing_instability)
    print("Stored Breathing Rate:", result.raw_metrics.get("breathing_rate"))
    print(
        "Has breathing instability note:",
        any("Breathing rate above threshold" in note for note in result.notes),
    )

    print("\nDSF Collapse Flag (should be False):", result.flags.dsf_collapse)
    print("Directional Collapse Flag (should be False):", result.flags.directional_collapse)
    print("Hysteresis Overload Flag (should be False):", result.flags.hysteresis_overload)


if __name__ == "__main__":
    main()
