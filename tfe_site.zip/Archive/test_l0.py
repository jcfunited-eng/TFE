import pandas as pd
from uf_core.layer0 import compute_sev_series

# simple artificial test to verify pipeline loads
df = pd.DataFrame({
    "Close": [100, 101, 102, 101, 103]
})

sev_list = compute_sev_series(df)
print("L0 Test OK. SEV count:", len(sev_list))
print("First SEV:", sev_list[0])
