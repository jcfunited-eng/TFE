import pandas as pd

from uf_core.layer0 import compute_sev_series
from uf_core.layer1 import segment_gates
from uf_core.config import KERNEL_THRESHOLDS


def main():
    # Simple synthetic series to trigger multiple gates
    # We deliberately vary F(t) to create some larger deviations.
    prices = [100, 101, 102, 110, 111, 112, 113, 90, 91, 92, 93, 94]

    df = pd.DataFrame({"Close": prices})

    # Compute SEVs using L0
    sev_list = compute_sev_series(df)

    # Optionally, adjust tau_D if needed to see more segmentation in this toy data
    print("Current tau_D:", KERNEL_THRESHOLDS.tau_D)

    gates = segment_gates(sev_list)

    print("L1 Test OK. Number of gates:", len(gates))
    for idx, g in enumerate(gates, start=1):
        print(f"Gate {idx}: start={g.start_idx}, end={g.end_idx}, "
              f"F[start]={prices[g.start_idx]}, F[end]={prices[g.end_idx]}")


if __name__ == "__main__":
    main()
