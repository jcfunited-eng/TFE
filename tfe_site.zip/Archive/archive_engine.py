import pandas as pd
import data_loader
import risk
import market as mkt   # sma, ema, macd, bollinger, rsi, momentum


# =========================================================
# PORTFOLIO + PRICES (shared across pages)
# =========================================================
def get_portfolio_and_prices():
    """
    Loads portfolio.csv and returns:
      positions: DataFrame
      tickers: list[str]
      latest_prices: dict {ticker: price}
      snapshot: portfolio snapshot object (portfolio.py)
    """
    df = pd.read_csv("portfolio.csv")
    df.columns = [c.lower().strip() for c in df.columns]

    if "asset_type" not in df.columns:
        df["asset_type"] = "equity"

    positions = df[["ticker", "quantity", "cost_basis", "asset_type"]].copy()
    tickers = list(positions["ticker"])

    latest = data_loader.latest_prices(tickers)

    import portfolio
    snapshot = portfolio.compute_portfolio_snapshot(positions, latest)

    return positions, tickers, latest, snapshot


# =========================================================
# HISTORY RANGE HELPER (Ticker Lookup uses this)
# =========================================================
def get_history_range(code: str):
    mapping = {
        "1D": ("1d", "1m"),
        "5D": ("5d", "5m"),
        "1M": ("1mo", "30m"),
        "6M": ("6mo", "1d"),
        "YTD": ("ytd", "1d"),
        "1Y": ("1y", "1d"),
        "5Y": ("5y", "1wk"),
        "MAX": ("max", "1mo"),
    }
    return mapping.get(code, ("6mo", "1d"))


# =========================================================
# SAMPLE LATEST PRICE (single ticker)
# =========================================================
def latest_price_single(ticker: str):
    """
    Safe helper to fetch a single latest price.
    Returns float or None.
    """
    try:
        prices = data_loader.latest_prices([ticker])
        return prices.get(ticker, None)
    except Exception:
        return None


# =========================================================
# PRICE HISTORY + INDICATORS (used everywhere)
# =========================================================
def get_history_with_indicators(ticker: str,
                                period: str = "6mo",
                                interval: str = "1d"):
    """
    Loads price history + computes all indicators.
    Always returns (df, ind).
    """
    try:
        df = data_loader.load_price_history(
            ticker,
            period=period,
            interval=interval
        )
    except Exception:
        return pd.DataFrame(), {}

    if df.empty:
        return pd.DataFrame(), {}

    df = df.sort_index()
    close = df["close"]

    # INDICATORS -------------------------------------------------------------
    sma20 = mkt.sma(close, 20)
    ema20 = mkt.ema(close, 20)
    bb_mid, bb_up, bb_low = mkt.bollinger_bands(close, 20, 2.0)
    rsi14 = mkt.rsi(close, 14)
    macd_line, macd_signal = mkt.macd(close)
    momentum10 = mkt.momentum(close, 10)

    # RISK METRICS -----------------------------------------------------------
    rets = risk.daily_returns(close)
    vol = risk.annualized_volatility(rets)
    sharpe = risk.sharpe_ratio(rets, 0.02)

    # FIX MAX DRAWDOWN SAFELY
    try:
        equity = (1 + rets).cumprod()
        max_dd = risk.max_drawdown(equity)
        if isinstance(max_dd, (tuple, list)):
            max_dd = float(max_dd[0])
    except Exception:
        max_dd = 0.0

    # PACKAGE OUTPUT ---------------------------------------------------------
    ind = {
        "close": close,
        "sma_20": sma20,
        "ema_20": ema20,
        "bb_mid": bb_mid,
        "bb_up": bb_up,
        "bb_low": bb_low,
        "rsi_14": rsi14,
        "macd_line": macd_line,
        "macd_signal": macd_signal,
        "momentum_10": momentum10,
        "volatility": float(vol) if vol is not None else 0.2,
        "sharpe": float(sharpe) if sharpe is not None else 0.0,
        "max_dd": float(max_dd),
    }

    return df, ind
