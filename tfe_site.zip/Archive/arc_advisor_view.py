# advisor_view.py
import streamlit as st
from advisor_engine import load_portfolio, compute_portfolio_insights
from recommendations_data import get_recommendations


def run():
    st.title("Unified Advisor View")
    st.write(
        "A combined perspective of your current portfolio "
        "and general market opportunities."
    )

    df = load_portfolio()

    # ---- PART 1: PORTFOLIO INSIGHTS ----
    st.header("📘 Portfolio Insights")

    if df is None or df.empty:
        st.warning("No portfolio data found. Please add positions first.")
        return

    insights = compute_portfolio_insights(df)

    # ---- Allocation Overview ----
    st.subheader("Allocation Overview")
    for row in insights["allocations"]:
        st.write(f"**{row['ticker']}** — {row['allocation']:.1f}%")

    # ---- Diversification ----
    st.subheader("Diversification Level")
    st.write(
        f"Your diversification level is **{insights['diversification']}**."
    )

    # ---- Top Holding ----
    st.subheader("Top Holding")
    st.write(
        f"Your largest position is **{insights['top_holding']['ticker']}** "
        f"at {insights['top_holding']['allocation']:.1f}% of total value."
    )

    # ---- Summary ----
    st.subheader("Summary")
    st.write(insights["summary"])

    # ---- PART 2: RECOMMENDATIONS ----
    st.header("📗 Recommendations (New Opportunities)")
    st.write("These are general market opportunities, not tied to your portfolio.")

    recs = get_recommendations()

    for category, items in recs.items():
        st.subheader(f"{category} Potential")
        for item in items:
            st.write(f"**{item['Ticker']}** — {item['Reason']}")

    st.info(
        "Note: Recommendations are general categories and not personalized "
        "investment advice."
    )


if __name__ == "__main__":
    run()
