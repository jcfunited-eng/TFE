"""
Test for exit_safemode() in safemode.py.

Scenarios:
1) SafeMode active with non-default fields → exit_safemode should:
       - set safe_mode to False
       - clear entry_step, entry_reasons, frozen_gates
       - preserve latest_metrics
2) SafeMode inactive → exit_safemode should return state unchanged.
"""

import os
import sys

# Ensure project root is importable
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = current_dir
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from uf_core.safemode import SafeModeState, exit_safemode
from uf_core.layer1 import Gate


def main():
    print("=== SafeMode Exit Test ===\n")

    # ----------------------------------------------------------
    # Case 1: SafeMode active with non-default fields
    # ----------------------------------------------------------
    gates = [Gate(start_idx=0, end_idx=10), Gate(start_idx=11, end_idx=20)]
    latest_metrics = {"S_UF": 0.75, "R_UF": 0.30}

    state_active = SafeModeState(
        safe_mode=True,
        entry_step=42,
        entry_reasons=["dsf_collapse", "composite_S_low"],
        frozen_gates=gates,
        latest_metrics=latest_metrics,
    )

    print("Original SafeModeState (active):")
    print(state_active)

    state_after_exit = exit_safemode(state_active)

    print("\nState after exit_safemode():")
    print(state_after_exit)

    print("\nExplicit Checks (active case):")
    print("safe_mode == False:", state_after_exit.safe_mode is False)
    print("entry_step is None:", state_after_exit.entry_step is None)
    print("entry_reasons cleared:", state_after_exit.entry_reasons == [])
    print("frozen_gates cleared:", state_after_exit.frozen_gates is None)
    print(
        "latest_metrics preserved:",
        state_after_exit.latest_metrics == latest_metrics,
    )

    # ----------------------------------------------------------
    # Case 2: SafeMode inactive → state unchanged
    # ----------------------------------------------------------
    state_inactive = SafeModeState(
        safe_mode=False,
        entry_step=None,
        entry_reasons=[],
        frozen_gates=None,
        latest_metrics={"S_UF": 0.8, "R_UF": 0.35},
    )

    print("\nOriginal SafeModeState (inactive):")
    print(state_inactive)

    state_after_exit_inactive = exit_safemode(state_inactive)

    print("\nState after exit_safemode() on inactive state:")
    print(state_after_exit_inactive)

    print("\nExplicit Checks (inactive case):")
    print("State unchanged:", state_after_exit_inactive == state_inactive)


if __name__ == "__main__":
    main()
